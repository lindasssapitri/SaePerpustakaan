package model;

import java.sql.Date;

public class Peminjaman {

    private int idPeminjaman;
    private String kodeBuku;
    private String kodeAnggota;
    private String namaAnggota;  // dari tabel mahasiswa (read-only, diisi dari query join)
    private String nip;
    private Date tanggalPinjam;
    private Date tanggalKembali;
    private int totalPinjam;

    public Peminjaman(int idPeminjaman, String kodeBuku, String kodeAnggota, String namaAnggota, String nip, Date tanggalPinjam, Date tanggalKembali, int totalPinjam) {
        this.idPeminjaman = idPeminjaman;
        this.kodeBuku = kodeBuku;
        this.kodeAnggota = kodeAnggota;
        this.namaAnggota = namaAnggota;
        this.nip = nip;
        this.tanggalPinjam = tanggalPinjam;
        this.tanggalKembali = tanggalKembali;
        this.totalPinjam = totalPinjam;
    }

    // Getter dan Setter
    public int getIdPeminjaman() {
        return idPeminjaman;
    }

    public void setIdPeminjaman(int idPeminjaman) {
        this.idPeminjaman = idPeminjaman;
    }

    public String getKodeBuku() {
        return kodeBuku;
    }

    public void setKodeBuku(String kodeBuku) {
        this.kodeBuku = kodeBuku;
    }

    public String getKodeAnggota() {
        return kodeAnggota;
    }

    public void setKodeAnggota(String kodeAnggota) {
        this.kodeAnggota = kodeAnggota;
    }

    public String getNamaAnggota() {
        return namaAnggota;
    }

    public void setNamaAnggota(String namaAnggota) {
        this.namaAnggota = namaAnggota;
    }

    public String getNip() {
        return nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }

    public Date getTanggalPinjam() {
        return tanggalPinjam;
    }

    public void setTanggalPinjam(Date tanggalPinjam) {
        this.tanggalPinjam = tanggalPinjam;
    }

    public Date getTanggalKembali() {
        return tanggalKembali;
    }

    public void setTanggalKembali(Date tanggalKembali) {
        this.tanggalKembali = tanggalKembali;
    }

    public int getTotalPinjam() {
        return totalPinjam;
    }

    public void setTotalPinjam(int totalPinjam) {
        this.totalPinjam = totalPinjam;
    }
}
