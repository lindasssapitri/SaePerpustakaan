package model;

public class Buku {
    private int id;
    private String kodeBuku, judul, penulis, penerbit, tahun;
    private String kodeRak, namaRak; // relasi rak
    private int stokBuku; // tambahan stok buku

    // Constructor lengkap termasuk stokBuku dan rak
    public Buku(int id, String kodeBuku, String judul, String penulis, String penerbit, String tahun,
                String kodeRak, String namaRak, int stokBuku) {
        this.id = id;
        this.kodeBuku = kodeBuku;
        this.judul = judul;
        this.penulis = penulis;
        this.penerbit = penerbit;
        this.tahun = tahun;
        this.kodeRak = kodeRak;
        this.namaRak = namaRak;
        this.stokBuku = stokBuku;
    }

    // Getter
    public int getId() { return id; }
    public String getKodeBuku() { return kodeBuku; }
    public String getJudul() { return judul; }
    public String getPenulis() { return penulis; }
    public String getPenerbit() { return penerbit; }
    public String getTahun() { return tahun; }
    public String getKodeRak() { return kodeRak; }
    public String getNamaRak() { return namaRak; }
    public int getStokBuku() { return stokBuku; }

    // Setter
    public void setId(int id) { this.id = id; }
    public void setKodeBuku(String kodeBuku) { this.kodeBuku = kodeBuku; }
    public void setJudul(String judul) { this.judul = judul; }
    public void setPenulis(String penulis) { this.penulis = penulis; }
    public void setPenerbit(String penerbit) { this.penerbit = penerbit; }
    public void setTahun(String tahun) { this.tahun = tahun; }
    public void setKodeRak(String kodeRak) { this.kodeRak = kodeRak; }
    public void setNamaRak(String namaRak) { this.namaRak = namaRak; }
    public void setStokBuku(int stokBuku) { this.stokBuku = stokBuku; }
}
