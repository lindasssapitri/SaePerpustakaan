package model;

public class User {
    private final int id_user;
    private int id_pegawai;
    private final String username;
    private final String password;
    private String role; // Tambahan field role

    // Konstruktor lengkap dengan role
    public User(int id, int id_pegawai, String username, String password, String role) {
        this.id_user = id;
        this.id_pegawai = id_pegawai;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    // Konstruktor alternatif jika role default
    public User(int id, int id_pegawai, String username, String password) {
        this(id, id_pegawai, username, password, "Petugas"); // Default role
    }

    // Getter dan Setter
    public int getIdUser() {
        return id_user;
    }

    public int getIdPegawai() {
        return id_pegawai;
    }

    public void setIdPegawai(int id_pegawai) {
        this.id_pegawai = id_pegawai;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
