package model;

public class Login {
    private int idUser;
    private int idPegawai;
    private String username;
    private String password;
    private String role;

    public Login(int idUser, int idPegawai, String username, String password, String role) {
        this.idUser = idUser;
        this.idPegawai = idPegawai;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    // Getter dan Setter

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public int getIdPegawai() {
        return idPegawai;
    }

    public void setIdPegawai(int idPegawai) {
        this.idPegawai = idPegawai;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
