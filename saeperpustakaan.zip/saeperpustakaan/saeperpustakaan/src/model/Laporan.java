package model;

public class Laporan {
    private int jumlahBuku;
    private int jumlahMahasiswa;
    private int jumlahPegawai;
    private int totalPeminjaman;
    private int jumlahArsipPengembalian;
    private int totalDenda;

    // Constructor
    public Laporan(int jumlahBuku, int jumlahMahasiswa, int jumlahPegawai, int totalPeminjaman,
                   int jumlahArsipPengembalian, int totalDenda) {
        this.jumlahBuku = jumlahBuku;
        this.jumlahMahasiswa = jumlahMahasiswa;
        this.jumlahPegawai = jumlahPegawai;
        this.totalPeminjaman = totalPeminjaman;
        this.jumlahArsipPengembalian = jumlahArsipPengembalian;
        this.totalDenda = totalDenda;
    }

    // Getter
    public int getJumlahBuku() {
        return jumlahBuku;
    }

    public int getJumlahMahasiswa() {
        return jumlahMahasiswa;
    }

    public int getJumlahPegawai() {
        return jumlahPegawai;
    }

    public int getTotalPeminjaman() {
        return totalPeminjaman;
    }

    public int getJumlahArsipPengembalian() {
        return jumlahArsipPengembalian;
    }

    public int getTotalDenda() {
        return totalDenda;
    }

    // Setter
    public void setJumlahBuku(int jumlahBuku) {
        this.jumlahBuku = jumlahBuku;
    }

    public void setJumlahMahasiswa(int jumlahMahasiswa) {
        this.jumlahMahasiswa = jumlahMahasiswa;
    }

    public void setJumlahPegawai(int jumlahPegawai) {
        this.jumlahPegawai = jumlahPegawai;
    }

    public void setTotalPeminjaman(int totalPeminjaman) {
        this.totalPeminjaman = totalPeminjaman;
    }

    public void setJumlahArsipPengembalian(int jumlahArsipPengembalian) {
        this.jumlahArsipPengembalian = jumlahArsipPengembalian;
    }

    public void setTotalDenda(int totalDenda) {
        this.totalDenda = totalDenda;
    }
}
