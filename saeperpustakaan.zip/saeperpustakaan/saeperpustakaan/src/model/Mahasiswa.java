package model;

public class Mahasiswa {
    private int idAnggota;
    private String kodeAnggota;
    private String nama;
    private String nim;
    private String jurusan;
    private String kontak;
    private String fotoAnggota; // Tambahan field foto_anggota

    // Constructor lengkap
    public Mahasiswa(int idAnggota, String kodeAnggota, String nama, String nim, String jurusan, String kontak, String fotoAnggota) {
        this.idAnggota = idAnggota;
        this.kodeAnggota = kodeAnggota;
        this.nama = nama;
        this.nim = nim;
        this.jurusan = jurusan;
        this.kontak = kontak;
        this.fotoAnggota = fotoAnggota;
    }

    // Getter dan Setter
    public int getIdAnggota() {
        return idAnggota;
    }

    public void setIdAnggota(int idAnggota) {
        this.idAnggota = idAnggota;
    }

    public String getKodeAnggota() {
        return kodeAnggota;
    }

    public void setKodeAnggota(String kodeAnggota) {
        this.kodeAnggota = kodeAnggota;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getJurusan() {
        return jurusan;
    }

    public void setJurusan(String jurusan) {
        this.jurusan = jurusan;
    }

    public String getKontak() {
        return kontak;
    }

    public void setKontak(String kontak) {
        this.kontak = kontak;
    }

    public String getFotoAnggota() {
        return fotoAnggota;
    }

    public void setFotoAnggota(String fotoAnggota) {
        this.fotoAnggota = fotoAnggota;
    }
}
