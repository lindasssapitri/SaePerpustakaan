package model;
public class Pegawai {
    private int id;
    private String nip;
    private String nama;
    private String jabatan;
    private String email;
    private String telepon;

    public Pegawai(int id, String nip, String nama, String jabatan, String email, String telepon) {
        this.id = id;
        this.nip = nip;
        this.nama = nama;
        this.jabatan = jabatan;
        this.email = email;
        this.telepon = telepon;
    }

    // Getter dan Setter
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNip() { return nip; }
    public void setNip(String nip) { this.nip = nip; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getJabatan() { return jabatan; }
    public void setJabatan(String jabatan) { this.jabatan = jabatan; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getTelepon() { return telepon; }
    public void setTelepon(String telepon) { this.telepon = telepon; }
}
