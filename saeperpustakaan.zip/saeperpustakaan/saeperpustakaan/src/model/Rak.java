package model;

public class Rak {
    private int idRak;
    private String kodeRak;
    private String namaRak;

    public Rak() {}

    public Rak(int idRak, String kodeRak, String namaRak) {
        this.idRak = idRak;
        this.kodeRak = kodeRak;
        this.namaRak = namaRak;
    }

    public int getIdRak() {
        return idRak;
    }

    public void setIdRak(int idRak) {
        this.idRak = idRak;
    }

    public String getKodeRak() {
        return kodeRak;
    }

    public void setKodeRak(String kodeRak) {
        this.kodeRak = kodeRak;
    }

    public String getNamaRak() {
        return namaRak;
    }

    public void setNamaRak(String namaRak) {
        this.namaRak = namaRak;
    }
}
