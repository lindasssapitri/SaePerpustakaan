package model;

import java.util.Date;

public class ArsipPeminjaman {

    private int idArsip;
    private String kodeAnggota;
    private String kodeBuku;
    private String nipPegawai;
    private Date tanggalPinjam;
    private Date tanggalKembali;
    private Date tanggalPengembalian;
    private int totalPinjam;
    private String kondisiBuku;
    private int totalDenda;

    // Constructor
    public ArsipPeminjaman(int idArsip, String kodeAnggota, String kodeBuku, String nipPegawai,
                           Date tanggalPinjam, Date tanggalKembali, Date tanggalPengembalian,
                           int totalPinjam, String kondisiBuku, int totalDenda) {
        this.idArsip = idArsip;
        this.kodeAnggota = kodeAnggota;
        this.kodeBuku = kodeBuku;
        this.nipPegawai = nipPegawai;
        this.tanggalPinjam = tanggalPinjam;
        this.tanggalKembali = tanggalKembali;
        this.tanggalPengembalian = tanggalPengembalian;
        this.totalPinjam = totalPinjam;
        this.kondisiBuku = kondisiBuku;
        this.totalDenda = totalDenda;
    }

    // Getters and Setters
    public int getIdArsip() {
        return idArsip;
    }

    public void setIdArsip(int idArsip) {
        this.idArsip = idArsip;
    }

    public String getKodeAnggota() {
        return kodeAnggota;
    }

    public void setKodeAnggota(String kodeAnggota) {
        this.kodeAnggota = kodeAnggota;
    }

    public String getKodeBuku() {
        return kodeBuku;
    }

    public void setKodeBuku(String kodeBuku) {
        this.kodeBuku = kodeBuku;
    }

    public String getNipPegawai() {
        return nipPegawai;
    }

    public void setNipPegawai(String nipPegawai) {
        this.nipPegawai = nipPegawai;
    }

    public Date getTanggalPinjam() {
        return tanggalPinjam;
    }

    public void setTanggalPinjam(Date tanggalPinjam) {
        this.tanggalPinjam = tanggalPinjam;
    }

    public Date getTanggalKembali() {
        return tanggalKembali;
    }

    public void setTanggalKembali(Date tanggalKembali) {
        this.tanggalKembali = tanggalKembali;
    }

    public Date getTanggalPengembalian() {
        return tanggalPengembalian;
    }

    public void setTanggalPengembalian(Date tanggalPengembalian) {
        this.tanggalPengembalian = tanggalPengembalian;
    }

    public int getTotalPinjam() {
        return totalPinjam;
    }

    public void setTotalPinjam(int totalPinjam) {
        this.totalPinjam = totalPinjam;
    }

    public String getKondisiBuku() {
        return kondisiBuku;
    }

    public void setKondisiBuku(String kondisiBuku) {
        this.kondisiBuku = kondisiBuku;
    }

    public int getTotalDenda() {
        return totalDenda;
    }

    public void setTotalDenda(int totalDenda) {
        this.totalDenda = totalDenda;
    }

    public Object getidArsip() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
