package controller;

import config.Koneksi;
import model.ArsipPeminjaman;

import java.sql.*;
import java.util.ArrayList;

public class ArsipPeminjamanController {

    // Method untuk mengambil semua data arsip peminjaman
    public ArrayList<ArsipPeminjaman> getAllArsip() {
        ArrayList<ArsipPeminjaman> list = new ArrayList<>();
        try {
            Connection conn = Koneksi.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM arsip_peminjaman");

            while (rs.next()) {
                ArsipPeminjaman a = new ArsipPeminjaman(
                        rs.getInt("id_arsip"),
                        rs.getString("kode_anggota"),
                        rs.getString("kode_buku"),
                        rs.getString("nip_pegawai"),
                        rs.getDate("tanggal_pinjam"),
                        rs.getDate("tanggal_kembali"),
                        rs.getDate("tanggal_pengembalian"),
                        rs.getInt("total_pinjam"),
                        rs.getString("kondisi_buku"),
                        rs.getInt("total_denda")
                );
                list.add(a);
            }

            System.out.println("Data arsip peminjaman ditemukan: " + list.size());
        } catch (SQLException e) {
            System.out.println("Error getAll arsip peminjaman: " + e.getMessage());
        }

        return list;
    }

    public boolean batalkanPengarsipan(int idArsip) {
    try (Connection conn = Koneksi.getConnection()) {
        conn.setAutoCommit(false); // supaya transaksional
        try {
            // 1. Ambil data dari arsip_peminjaman berdasarkan id_arsip
            String sqlSelect = "SELECT * FROM arsip_peminjaman WHERE id_arsip = ?";
            try (PreparedStatement psSelect = conn.prepareStatement(sqlSelect)) {
                psSelect.setInt(1, idArsip);
                try (ResultSet rs = psSelect.executeQuery()) {
                    if (!rs.next()) {
                        conn.rollback();
                        return false; // data arsip tidak ditemukan
                    }

                    // Ambil data dari arsip
                    String kodeAnggota = rs.getString("kode_anggota");
                    String kodeBuku = rs.getString("kode_buku");
                    String nipPegawai = rs.getString("nip_pegawai");
                    Date tanggalPinjam = rs.getDate("tanggal_pinjam");
                    Date tanggalKembali = rs.getDate("tanggal_kembali");
                    int totalPinjam = rs.getInt("total_pinjam");

                    // 2. Masukkan kembali ke peminjaman
                    String sqlInsert = "INSERT INTO peminjaman "
                            + "(kode_anggota, kode_buku, nip, tanggal_pinjam, tanggal_kembali, total_pinjam) "
                            + "VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement psInsert = conn.prepareStatement(sqlInsert)) {
                        psInsert.setString(1, kodeAnggota);
                        psInsert.setString(2, kodeBuku);
                        psInsert.setString(3, nipPegawai);
                        psInsert.setDate(4, tanggalPinjam);
                        psInsert.setDate(5, tanggalKembali);
                        psInsert.setInt(6, totalPinjam);

                        int inserted = psInsert.executeUpdate();
                        if (inserted == 0) {
                            conn.rollback();
                            return false; // gagal insert
                        }
                    }

                    // 3. Kurangi kembali stok buku
                    String sqlUpdateStok = "UPDATE buku SET stok_buku = stok_buku - ? WHERE kode_buku = ?";
                    try (PreparedStatement psUpdateStok = conn.prepareStatement(sqlUpdateStok)) {
                        psUpdateStok.setInt(1, totalPinjam);
                        psUpdateStok.setString(2, kodeBuku);
                        psUpdateStok.executeUpdate();
                    }

                    // 4. Hapus data dari arsip_peminjaman
                    String sqlDelete = "DELETE FROM arsip_peminjaman WHERE id_arsip = ?";
                    try (PreparedStatement psDelete = conn.prepareStatement(sqlDelete)) {
                        psDelete.setInt(1, idArsip);
                        int deleted = psDelete.executeUpdate();
                        if (deleted == 0) {
                            conn.rollback();
                            return false;
                        }
                    }

                    conn.commit();
                    return true;
                }
            }
        } catch (SQLException ex) {
            conn.rollback();
            ex.printStackTrace();
            return false;
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
}


    // Delete Data Arsip Peminjaman
    public void deleteArsipPeminjaman(int idArsip) {
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "DELETE FROM arsip_peminjaman WHERE id_arsip = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, idArsip);
            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Arsip peminjaman berhasil dihapus!");
            } else {
                System.out.println("Data arsip tidak ditemukan atau gagal dihapus.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleteArsipPeminjaman: " + e.getMessage());
        }
    }

    public ArrayList<ArsipPeminjaman> getAllArsip(Date tanggalAwal, Date tanggalAkhir) {
        ArrayList<ArsipPeminjaman> list = new ArrayList<>();
        try {
            Connection conn = Koneksi.getConnection();

            String sql = "SELECT * FROM arsip_peminjaman WHERE tanggal_input_arsip BETWEEN ? AND ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, new java.sql.Date(tanggalAwal.getTime()));
            ps.setDate(2, new java.sql.Date(tanggalAkhir.getTime()));

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                ArsipPeminjaman a = new ArsipPeminjaman(
                        rs.getInt("id_arsip"),
                        rs.getString("kode_anggota"),
                        rs.getString("kode_buku"),
                        rs.getString("nip_pegawai"),
                        rs.getDate("tanggal_pinjam"),
                        rs.getDate("tanggal_kembali"),
                        rs.getDate("tanggal_pengembalian"),
                        rs.getInt("total_pinjam"),
                        rs.getString("kondisi_buku"),
                        rs.getInt("total_denda")
                );
                list.add(a);
            }

            System.out.println("Data arsip peminjaman dalam rentang tanggal input arsip: " + list.size());

        } catch (SQLException e) {
            System.out.println("Error getAllArsip dengan filter tanggal input arsip: " + e.getMessage());
        }

        return list;
    }

    public int getTotalDenda(Date tanggalAwal, Date tanggalAkhir) {
        int totalDenda = 0;

        try {
            Connection conn = Koneksi.getConnection();

            String sql = "SELECT SUM(total_denda) AS total_denda FROM arsip_peminjaman WHERE tanggal_input_arsip BETWEEN ? AND ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, new java.sql.Date(tanggalAwal.getTime()));
            ps.setDate(2, new java.sql.Date(tanggalAkhir.getTime()));

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                totalDenda = rs.getInt("total_denda");
            }

            System.out.println("Total denda dalam rentang tanggal input arsip: " + totalDenda);

        } catch (SQLException e) {
            System.out.println("Error getTotalDenda: " + e.getMessage());
        }

        return totalDenda;
    }

}
