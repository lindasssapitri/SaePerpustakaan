package controller;

import config.Koneksi;
import model.Buku;

import java.sql.*;
import java.util.ArrayList;

public class BukuController {

    // Fungsi lama, tanpa filter tanggal
    public ArrayList<Buku> getAll() {
        ArrayList<Buku> list = new ArrayList<>();
        try {
            Connection conn = Koneksi.getConnection();
            Statement st = conn.createStatement();

            String sql = "SELECT b.id_buku, b.kode_buku, b.judul, b.penulis, b.penerbit, b.tahun_terbit, " +
                         "r.kode_rak, r.nama_rak, b.stok_buku " +
                         "FROM buku b LEFT JOIN rak r ON b.id_rak = r.id_rak";

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                Buku b = new Buku(
                        rs.getInt("id_buku"),
                        rs.getString("kode_buku"),
                        rs.getString("judul"),
                        rs.getString("penulis"),
                        rs.getString("penerbit"),
                        rs.getString("tahun_terbit"),
                        rs.getString("kode_rak"),
                        rs.getString("nama_rak"),
                        rs.getInt("stok_buku")
                );
                list.add(b);
            }
            System.out.println("Data buku: " + list.size());
        } catch (SQLException e) {
            System.out.println("Error getAll buku: " + e.getMessage());
        }
        return list;
    }

    // Fungsi baru, dengan filter tanggal
    public ArrayList<Buku> getAll(Date tanggalAwal, Date tanggalAkhir) {
        ArrayList<Buku> list = new ArrayList<>();
        try {
            Connection conn = Koneksi.getConnection();

            String sql = "SELECT b.id_buku, b.kode_buku, b.judul, b.penulis, b.penerbit, b.tahun_terbit, " +
                         "r.kode_rak, r.nama_rak, b.stok_buku, b.tanggal_input_buku " +
                         "FROM buku b LEFT JOIN rak r ON b.id_rak = r.id_rak " +
                         "WHERE b.tanggal_input_buku BETWEEN ? AND ?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, new java.sql.Date(tanggalAwal.getTime()));
            ps.setDate(2, new java.sql.Date(tanggalAkhir.getTime()));

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Buku b = new Buku(
                        rs.getInt("id_buku"),
                        rs.getString("kode_buku"),
                        rs.getString("judul"),
                        rs.getString("penulis"),
                        rs.getString("penerbit"),
                        rs.getString("tahun_terbit"),
                        rs.getString("kode_rak"),
                        rs.getString("nama_rak"),
                        rs.getInt("stok_buku")
                );
                list.add(b);
            }
            System.out.println("Data buku dalam rentang tanggal: " + list.size());
        } catch (SQLException e) {
            System.out.println("Error getAll buku dengan filter tanggal: " + e.getMessage());
        }
        return list;
    }


    public void tambahBuku(Buku b, int idRak) {
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "INSERT INTO buku (kode_buku, judul, penulis, penerbit, tahun_terbit, id_rak, stok_buku) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, b.getKodeBuku());
            pst.setString(2, b.getJudul());
            pst.setString(3, b.getPenulis());
            pst.setString(4, b.getPenerbit());
            pst.setString(5, b.getTahun());
            pst.setInt(6, idRak);
            pst.setInt(7, b.getStokBuku());  // stok buku
            pst.executeUpdate();
            System.out.println("Buku berhasil ditambah!");
        } catch (SQLException e) {
            System.out.println("Error tambahBuku: " + e.getMessage());
        }
    }

    public void updateBuku(Buku b, int idRak) {
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "UPDATE buku SET kode_buku=?, judul=?, penulis=?, penerbit=?, tahun_terbit=?, id_rak=?, stok_buku=? WHERE id_buku=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, b.getKodeBuku());
            pst.setString(2, b.getJudul());
            pst.setString(3, b.getPenulis());
            pst.setString(4, b.getPenerbit());
            pst.setString(5, b.getTahun());
            pst.setInt(6, idRak);
            pst.setInt(7, b.getStokBuku());  // stok buku
            pst.setInt(8, b.getId());
            pst.executeUpdate();
            System.out.println("Buku berhasil diupdate!");
        } catch (SQLException e) {
            System.out.println("Error updateBuku: " + e.getMessage());
        }
    }

    public void deleteBuku(int id) {
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "DELETE FROM buku WHERE id_buku=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, id);
            pst.executeUpdate();
            System.out.println("Buku berhasil dihapus!");
        } catch (SQLException e) {
            System.out.println("Error deleteBuku: " + e.getMessage());
        }
    }

    public String generateKodeBuku() {
        String kodeBaru = "BK0001";
        try {
            Connection conn = Koneksi.getConnection();
            Statement st = conn.createStatement();
            String sql = "SELECT kode_buku FROM buku ORDER BY kode_buku DESC LIMIT 1";
            ResultSet rs = st.executeQuery(sql);

            if (rs.next()) {
                String kodeTerakhir = rs.getString("kode_buku");
                int angkaTerakhir = Integer.parseInt(kodeTerakhir.substring(2));
                int angkaBaru = angkaTerakhir + 1;
                kodeBaru = String.format("BK%04d", angkaBaru);
            }
        } catch (SQLException e) {
            System.out.println("Error generateKodeBuku: " + e.getMessage());
        }
        return kodeBaru;
    }
}
