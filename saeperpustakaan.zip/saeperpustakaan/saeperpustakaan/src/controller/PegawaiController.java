package controller;

import config.Koneksi;
import model.Pegawai;
import model.User;
import java.sql.*;
import java.util.ArrayList;

public class PegawaiController {

    // Method untuk mengambil semua data pegawai
    public ArrayList<Pegawai> getAll() {
        ArrayList<Pegawai> list = new ArrayList<>();
        try {
            Connection conn = Koneksi.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM pegawai");

            while (rs.next()) {
                Pegawai p = new Pegawai(
                        rs.getInt("id_pegawai"),
                        rs.getString("nip"),
                        rs.getString("nama"),
                        rs.getString("jabatan"),
                        rs.getString("email"),
                        rs.getString("telepon")
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error getAll Pegawai: " + e.getMessage());
        }
        return list;
    }

    // Fungsi baru, dengan filter tanggal
    public ArrayList<Pegawai> getAllByTanggal(java.sql.Date tanggalAwal, java.sql.Date tanggalAkhir) {
        ArrayList<Pegawai> list = new ArrayList<>();
        String sql = "SELECT * FROM pegawai WHERE tanggal_input_pegawai BETWEEN ? AND ?";
        try (Connection conn = Koneksi.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setDate(1, tanggalAwal);
            pst.setDate(2, tanggalAkhir);

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Pegawai p = new Pegawai(
                        rs.getInt("id_pegawai"),
                        rs.getString("nip"),
                        rs.getString("nama"),
                        rs.getString("jabatan"),
                        rs.getString("email"),
                        rs.getString("telepon")
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error getAllByTanggal Pegawai: " + e.getMessage());
        }
        return list;
    }

    public void tambahPegawai(Pegawai p, User u) {
        Connection conn = null;
        PreparedStatement pstPegawai = null, pstUser = null;
        try {
            conn = Koneksi.getConnection();
            conn.setAutoCommit(false);  // Memulai transaksi

            // Menambahkan data ke tabel pegawai
            String sqlPegawai = "INSERT INTO pegawai (nip, nama, jabatan, email, telepon) VALUES (?, ?, ?, ?, ?)";
            pstPegawai = conn.prepareStatement(sqlPegawai, Statement.RETURN_GENERATED_KEYS);
            pstPegawai.setString(1, p.getNip());
            pstPegawai.setString(2, p.getNama());
            pstPegawai.setString(3, p.getJabatan());
            pstPegawai.setString(4, p.getEmail());
            pstPegawai.setString(5, p.getTelepon());

            pstPegawai.executeUpdate();

            // Ambil id_pegawai yang baru saja ditambahkan
            ResultSet rs = pstPegawai.getGeneratedKeys();
            if (rs.next()) {
                int idPegawai = rs.getInt(1);

                // Menambahkan data ke tabel user dengan kolom role
                String sqlUser = "INSERT INTO user (id_pegawai, username, password, role) VALUES (?, ?, ?, ?)";
                pstUser = conn.prepareStatement(sqlUser);
                pstUser.setInt(1, idPegawai);
                pstUser.setString(2, u.getUsername());
                pstUser.setString(3, u.getPassword());
                pstUser.setString(4, u.getRole());  // <-- Tambahkan role di sini
                pstUser.executeUpdate();
            }

            conn.commit();  // Menyelesaikan transaksi
            System.out.println("Pegawai dan User berhasil ditambah!");
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();  // Jika terjadi error, rollback transaksi
                } catch (SQLException ex) {
                    System.out.println("Error rollback: " + ex.getMessage());
                }
            }
            System.out.println("Error tambahPegawai: " + e.getMessage());
        } finally {
            try {
                if (pstPegawai != null) {
                    pstPegawai.close();
                }
                if (pstUser != null) {
                    pstUser.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }

    // Method untuk memperbarui pegawai dan user
    public void updatePegawai(Pegawai p, User u) {
        Connection conn = null;
        PreparedStatement pstPegawai = null, pstUser = null;
        try {
            conn = Koneksi.getConnection();
            conn.setAutoCommit(false);

            String sqlPegawai = "UPDATE pegawai SET nip=?, nama=?, jabatan=?, email=?, telepon=? WHERE id_pegawai=?";
            pstPegawai = conn.prepareStatement(sqlPegawai);
            pstPegawai.setString(1, p.getNip());
            pstPegawai.setString(2, p.getNama());
            pstPegawai.setString(3, p.getJabatan());
            pstPegawai.setString(4, p.getEmail());
            pstPegawai.setString(5, p.getTelepon());
            pstPegawai.setInt(6, p.getId());
            pstPegawai.executeUpdate();

            String sqlUser = "UPDATE user SET username=?, password=?, role=? WHERE id_pegawai=?";
            pstUser = conn.prepareStatement(sqlUser);
            pstUser.setString(1, u.getUsername());
            pstUser.setString(2, u.getPassword());
            pstUser.setString(3, u.getRole());   // perbarui role juga
            pstUser.setInt(4, p.getId());
            pstUser.executeUpdate();

            conn.commit();
            System.out.println("Pegawai dan User berhasil diupdate!");
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    System.out.println("Error rollback: " + ex.getMessage());
                }
            }
            System.out.println("Error updatePegawai: " + e.getMessage());
        } finally {
            try {
                if (pstPegawai != null) {
                    pstPegawai.close();
                }
                if (pstUser != null) {
                    pstUser.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error closing resources: " + e.getMessage());
            }
        }
    }

    // Method untuk menghapus pegawai
    public void deletePegawai(int id) {
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "DELETE FROM pegawai WHERE id_pegawai=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, id);
            pst.executeUpdate();
            System.out.println("Pegawai berhasil dihapus!");
        } catch (SQLException e) {
            System.out.println("Error deletePegawai: " + e.getMessage());
        }
    }

    public String generateNip() {
        String nipBaru = "NIP0001";
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "SELECT nip FROM pegawai ORDER BY id_pegawai DESC LIMIT 1";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String lastNip = rs.getString("nip"); // misal: NIP0021
                int nomor = Integer.parseInt(lastNip.substring(3)); // ambil angka 0021
                nomor++; // tambah 1
                nipBaru = String.format("NIP%04d", nomor); // NIP0022
            }
        } catch (SQLException e) {
            System.out.println("Error generateNip: " + e.getMessage());
        }
        return nipBaru;
    }

}
