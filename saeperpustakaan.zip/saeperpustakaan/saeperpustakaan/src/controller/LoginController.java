package controller;

import config.Koneksi;
import model.Login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginController {

    // Fungsi login: cek username dan password, return Login object jika berhasil, null jika gagal
    public Login loginUser(String username, String password) {
        Login user = null;
        try {
            Connection conn = Koneksi.getConnection();

            String sql = "SELECT * FROM user WHERE username = ? AND password = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, username);
            pst.setString(2, password);  // Idealnya password sudah di-hash

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                user = new Login(
                    rs.getInt("id_user"),
                    rs.getInt("id_pegawai"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("role")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error loginUser: " + e.getMessage());
        }
        return user;
    }

    // Ambil user berdasarkan username
    public Login getUserByUsername(String username) {
        Login user = null;
        try {
            Connection conn = Koneksi.getConnection();

            String sql = "SELECT * FROM user WHERE username = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, username);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                user = new Login(
                    rs.getInt("id_user"),
                    rs.getInt("id_pegawai"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("role")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error getUserByUsername: " + e.getMessage());
        }
        return user;
    }
}
