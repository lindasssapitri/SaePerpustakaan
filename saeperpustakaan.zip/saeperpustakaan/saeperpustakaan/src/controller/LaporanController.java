package controller;

import config.Koneksi;
import model.Laporan;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LaporanController {

    public Laporan getLaporan() {
        Laporan laporan = null;

        try {
            Connection conn = Koneksi.getConnection();
            Statement st = conn.createStatement();

            // Query jumlah buku
            ResultSet rsBuku = st.executeQuery("SELECT COUNT(*) AS jumlah FROM buku");
            int jumlahBuku = rsBuku.next() ? rsBuku.getInt("jumlah") : 0;

            // Query jumlah mahasiswa
            ResultSet rsMhs = st.executeQuery("SELECT COUNT(*) AS jumlah FROM mahasiswa");
            int jumlahMahasiswa = rsMhs.next() ? rsMhs.getInt("jumlah") : 0;

            // Query jumlah pegawai
            ResultSet rsPegawai = st.executeQuery("SELECT COUNT(*) AS jumlah FROM pegawai");
            int jumlahPegawai = rsPegawai.next() ? rsPegawai.getInt("jumlah") : 0;

            // Query total peminjaman
            ResultSet rsPeminjaman = st.executeQuery("SELECT COUNT(*) AS jumlah FROM peminjaman");
            int totalPeminjaman = rsPeminjaman.next() ? rsPeminjaman.getInt("jumlah") : 0;

            // Jumlah arsip pengembalian dari arsip_peminjaman
            ResultSet rsArsip = st.executeQuery("SELECT COUNT(*) AS jumlah FROM arsip_peminjaman");
            int jumlahArsip = rsArsip.next() ? rsArsip.getInt("jumlah") : 0;

            // Total denda dari arsip_peminjaman
            ResultSet rsDenda = st.executeQuery("SELECT SUM(total_denda) AS total FROM arsip_peminjaman");
            int totalDenda = 0;
            if (rsDenda.next()) {
                totalDenda = rsDenda.getInt("total");
            }

            laporan = new Laporan(
                    jumlahBuku,
                    jumlahMahasiswa,
                    jumlahPegawai,
                    totalPeminjaman,
                    jumlahArsip,
                    totalDenda
            );

            System.out.println("Laporan berhasil dibuat");

        } catch (SQLException e) {
            System.out.println("Error getLaporan: " + e.getMessage());
        }

        return laporan;
    }
    
}
