package controller;

import config.Koneksi;
import model.Peminjaman;

import java.sql.*;
import java.util.ArrayList;

public class PeminjamanController {

    // Mengambil data untuk ditampilkan
    public ArrayList<Peminjaman> getAll() {
        ArrayList<Peminjaman> list = new ArrayList<>();
        String sql = "SELECT p.id_peminjaman, p.kode_buku, p.kode_anggota, m.nama, p.nip, p.tanggal_pinjam, p.tanggal_kembali, p.total_pinjam "
                + "FROM peminjaman p "
                + "JOIN mahasiswa m ON p.kode_anggota = m.kode_anggota";

        try (Connection conn = Koneksi.getConnection(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Peminjaman p = new Peminjaman(
                        rs.getInt("id_peminjaman"),
                        rs.getString("kode_buku"),
                        rs.getString("kode_anggota"),
                        rs.getString("nama"), // nama anggota langsung lewat konstruktor
                        rs.getString("nip"),
                        rs.getDate("tanggal_pinjam"),
                        rs.getDate("tanggal_kembali"),
                        rs.getInt("total_pinjam") // pastikan ini ada di tabel database
                );
                list.add(p);
            }

        } catch (SQLException e) {
            System.out.println("Error getAll peminjaman: " + e.getMessage());
        }

        return list;
    }

    // Fungsi baru, dengan filter tanggal untuk data peminjaman
    public ArrayList<Peminjaman> getAll(Date tanggalAwal, Date tanggalAkhir) {
        ArrayList<Peminjaman> list = new ArrayList<>();
        try {
            Connection conn = Koneksi.getConnection();

            String sql = "SELECT p.id_peminjaman, p.kode_buku, p.kode_anggota, m.nama, p.nip, "
                    + "p.tanggal_pinjam, p.tanggal_kembali, p.total_pinjam "
                    + "FROM peminjaman p LEFT JOIN mahasiswa m ON p.kode_anggota = m.kode_anggota "
                    + "WHERE p.tanggal_pinjam BETWEEN ? AND ?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, new java.sql.Date(tanggalAwal.getTime()));
            ps.setDate(2, new java.sql.Date(tanggalAkhir.getTime()));

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Peminjaman p = new Peminjaman(
                        rs.getInt("id_peminjaman"),
                        rs.getString("kode_buku"),
                        rs.getString("kode_anggota"),
                        rs.getString("nama"),
                        rs.getString("nip"),
                        rs.getDate("tanggal_pinjam"),
                        rs.getDate("tanggal_kembali"),
                        rs.getInt("total_pinjam")
                );
                list.add(p);
            }
            System.out.println("Data peminjaman dalam rentang tanggal: " + list.size());

        } catch (SQLException e) {
            System.out.println("Error getAll peminjaman dengan filter tanggal: " + e.getMessage());
        }
        return list;
    }

    public ArrayList<String> getKodeAnggotaWithNama() {
        ArrayList<String> list = new ArrayList<>();
        String sql = "SELECT kode_anggota, nama FROM mahasiswa";

        try (Connection conn = Koneksi.getConnection(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                String kode = rs.getString("kode_anggota");
                String nama = rs.getString("nama");
                list.add(kode + " - " + nama);
            }

        } catch (SQLException e) {
            System.out.println("Error getKodeAnggotaWithNama: " + e.getMessage());
        }

        return list;
    }

    public ArrayList<String> getNipPegawaiWithNama() {
        ArrayList<String> list = new ArrayList<>();
        String sql = "SELECT nip, nama FROM pegawai";

        try (Connection conn = Koneksi.getConnection(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                String nip = rs.getString("nip");
                String nama = rs.getString("nama");
                list.add(nip + " - " + nama);
            }

        } catch (SQLException e) {
            System.out.println("Error getNipPegawaiWithNama: " + e.getMessage());
        }

        return list;
    }

    public ArrayList<String> getKodeBukuWithJudulAndStok() {
        ArrayList<String> list = new ArrayList<>();
        String sql = "SELECT kode_buku, judul, stok_buku FROM buku";

        try (Connection conn = Koneksi.getConnection(); Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                String kode = rs.getString("kode_buku");
                String judul = rs.getString("judul");
                int stok = rs.getInt("stok_buku");
                list.add(kode + " - " + judul + " (stok: " + stok + ")");
            }

        } catch (SQLException e) {
            System.out.println("Error getKodeBukuWithJudulAndStok: " + e.getMessage());
        }

        return list;
    }

    public void tambahPeminjaman(Peminjaman p) throws SQLException {
        System.out.println("DEBUG: masuk tambahPeminjaman dengan totalPinjam = " + p.getTotalPinjam());
        try (Connection conn = Koneksi.getConnection()) {
            conn.setAutoCommit(false);
            try {
                String cekStokSql = "SELECT stok_buku FROM buku WHERE kode_buku = ? FOR UPDATE";
                int stok = 0;
                try (PreparedStatement pstCek = conn.prepareStatement(cekStokSql)) {
                    pstCek.setString(1, p.getKodeBuku());
                    try (ResultSet rs = pstCek.executeQuery()) {
                        if (rs.next()) {
                            stok = rs.getInt("stok_buku");
                            System.out.println("DEBUG: stok buku dari DB = " + stok);
                        } else {
                            throw new SQLException("Kode buku tidak ditemukan.");
                        }
                    }
                }

                System.out.println("Stok buku saat ini: " + stok);
                System.out.println("Jumlah yang dipinjam: " + p.getTotalPinjam());

                if (stok <= 0 || stok < p.getTotalPinjam()) {
                    throw new SQLException("Stok buku tidak cukup. Stok tersedia: " + stok);
                }

                String updateStok = "UPDATE buku SET stok_buku = stok_buku - ? WHERE kode_buku = ?";
                try (PreparedStatement pst1 = conn.prepareStatement(updateStok)) {
                    pst1.setInt(1, p.getTotalPinjam());
                    pst1.setString(2, p.getKodeBuku());
                    pst1.executeUpdate();
                }

                String sql = "INSERT INTO peminjaman (kode_buku, kode_anggota, nip, tanggal_pinjam, tanggal_kembali, total_pinjam) VALUES (?, ?, ?, ?, ?, ?)";
                try (PreparedStatement pst2 = conn.prepareStatement(sql)) {
                    pst2.setString(1, p.getKodeBuku());
                    pst2.setString(2, p.getKodeAnggota());
                    pst2.setString(3, p.getNip());
                    pst2.setDate(4, p.getTanggalPinjam());
                    pst2.setDate(5, p.getTanggalKembali());
                    pst2.setInt(6, p.getTotalPinjam());
                    pst2.executeUpdate();
                }

                conn.commit();
            } catch (SQLException e) {
                conn.rollback();  // rollback jika ada error
                throw e;
            }
        }
    }

    // Memperbarui data peminjaman
    public void updatePeminjaman(Peminjaman p) {
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "UPDATE peminjaman SET kode_buku=?, kode_anggota=?, nip=?, tanggal_pinjam=?, tanggal_kembali=?, total_pinjam=? WHERE id_peminjaman=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, p.getKodeBuku());
            pst.setString(2, p.getKodeAnggota());
            pst.setString(3, p.getNip());
            pst.setDate(4, p.getTanggalPinjam());
            pst.setDate(5, p.getTanggalKembali());
            pst.setInt(6, p.getTotalPinjam()); // ⬅️ Tambahan field jumlah pinjam
            pst.setInt(7, p.getIdPeminjaman()); // ⬅️ Geser ke parameter ke-7
            pst.executeUpdate();
            System.out.println("Data peminjaman berhasil diupdate!");
        } catch (SQLException e) {
            System.out.println("Error updatePeminjaman: " + e.getMessage());
        }
    }

   // Menghapus data peminjaman & mengembalikan stok buku
public void deletePeminjaman(int id) {
    try (Connection conn = Koneksi.getConnection()) {
        conn.setAutoCommit(false); // transaksional

        try {
            // 1. Ambil kode_buku dan total_pinjam dulu
            String sqlSelect = "SELECT kode_buku, total_pinjam FROM peminjaman WHERE id_peminjaman=?";
            String kodeBuku = null;
            int totalPinjam = 0;

            try (PreparedStatement psSelect = conn.prepareStatement(sqlSelect)) {
                psSelect.setInt(1, id);
                try (ResultSet rs = psSelect.executeQuery()) {
                    if (rs.next()) {
                        kodeBuku = rs.getString("kode_buku");
                        totalPinjam = rs.getInt("total_pinjam");
                    } else {
                        System.out.println("Data peminjaman tidak ditemukan.");
                        conn.rollback();
                        return;
                    }
                }
            }

            // 2. Hapus peminjaman
            String sqlDelete = "DELETE FROM peminjaman WHERE id_peminjaman=?";
            try (PreparedStatement psDelete = conn.prepareStatement(sqlDelete)) {
                psDelete.setInt(1, id);
                int deleted = psDelete.executeUpdate();
                if (deleted == 0) {
                    System.out.println("Gagal menghapus data peminjaman.");
                    conn.rollback();
                    return;
                }
            }

            // 3. Kembalikan stok buku
            String sqlUpdateStok = "UPDATE buku SET stok_buku = stok_buku + ? WHERE kode_buku=?";
            try (PreparedStatement psUpdateStok = conn.prepareStatement(sqlUpdateStok)) {
                psUpdateStok.setInt(1, totalPinjam);
                psUpdateStok.setString(2, kodeBuku);
                psUpdateStok.executeUpdate();
            }

            conn.commit();
            System.out.println("Data peminjaman berhasil dihapus & stok buku dikembalikan!");

        } catch (SQLException e) {
            conn.rollback();
            System.out.println("Error deletePeminjaman (rollback): " + e.getMessage());
        }

    } catch (SQLException e) {
        System.out.println("Error deletePeminjaman: " + e.getMessage());
    }
}


    // Proses Pengarsipan Peminjaman
    public boolean selesaikanPeminjaman(int idPinjam, Date tanggalPengembalian, String kondisiBuku, int totalDenda) {
        try (Connection conn = Koneksi.getConnection()) {
            conn.setAutoCommit(false); // transaksional supaya aman
            try {
                // 1. Ambil data dari tabel peminjaman
                String sqlSelect = "SELECT * FROM peminjaman WHERE id_peminjaman = ?";
                try (PreparedStatement psSelect = conn.prepareStatement(sqlSelect)) {
                    psSelect.setInt(1, idPinjam);
                    try (ResultSet rs = psSelect.executeQuery()) {
                        if (!rs.next()) {
                            conn.rollback();
                            return false; // data tidak ditemukan
                        }

                        // Ambil data dari hasil SELECT
                        String kodeAnggota = rs.getString("kode_anggota");
                        String kodeBuku = rs.getString("kode_buku");
                        String nipPegawai = rs.getString("nip");
                        Date tanggalPinjam = rs.getDate("tanggal_pinjam");
                        Date tanggalKembali = rs.getDate("tanggal_kembali");
                        int totalPinjam = rs.getInt("total_pinjam");

                        // 2. Masukkan data ke arsip_peminjaman
                        String sqlInsert = "INSERT INTO arsip_peminjaman "
                                + "(kode_anggota, kode_buku, nip_pegawai, tanggal_pinjam, tanggal_kembali, tanggal_pengembalian, total_pinjam, kondisi_buku, total_denda) "
                                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

                        try (PreparedStatement psInsert = conn.prepareStatement(sqlInsert)) {
                            psInsert.setString(1, kodeAnggota);
                            psInsert.setString(2, kodeBuku);
                            psInsert.setString(3, nipPegawai);
                            psInsert.setDate(4, tanggalPinjam);
                            psInsert.setDate(5, tanggalKembali);
                            psInsert.setDate(6, tanggalPengembalian);
                            psInsert.setInt(7, totalPinjam);
                            psInsert.setString(8, kondisiBuku);
                            psInsert.setInt(9, totalDenda);

                            int inserted = psInsert.executeUpdate();
                            if (inserted == 0) {
                                conn.rollback();
                                return false; // gagal insert
                            }
                        }

                        // 3. Update stok buku (tambah kembali)
                        String sqlUpdateStok = "UPDATE buku SET stok_buku = stok_buku + ? WHERE kode_buku = ?";
                        try (PreparedStatement psUpdateStok = conn.prepareStatement(sqlUpdateStok)) {
                            psUpdateStok.setInt(1, totalPinjam);
                            psUpdateStok.setString(2, kodeBuku);
                            psUpdateStok.executeUpdate();
                        }

                        // 4. Hapus data dari peminjaman
                        String sqlDelete = "DELETE FROM peminjaman WHERE id_peminjaman = ?";
                        try (PreparedStatement psDelete = conn.prepareStatement(sqlDelete)) {
                            psDelete.setInt(1, idPinjam);
                            int deleted = psDelete.executeUpdate();
                            if (deleted == 0) {
                                conn.rollback();
                                return false;
                            }
                        }

                        conn.commit();
                        return true;
                    }
                }
            } catch (SQLException ex) {
                conn.rollback();
                ex.printStackTrace();
                return false;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean batalkanPengarsipan(int idArsip) {
        System.out.println("Mulai proses batalkan pengarsipan untuk id_arsip: " + idArsip);
        try (Connection conn = Koneksi.getConnection()) {
            String sqlSelect = "SELECT * FROM arsip_peminjaman WHERE id_arsip = ?";
            try (PreparedStatement psSelect = conn.prepareStatement(sqlSelect)) {
                psSelect.setInt(1, idArsip);
                try (ResultSet rs = psSelect.executeQuery()) {
                    if (!rs.next()) {
                        System.out.println("Data arsip dengan id " + idArsip + " tidak ditemukan.");
                        return false;
                    }

                    // Ambil data lengkap dari arsip
                    String kodeAnggota = rs.getString("kode_anggota");
                    String kodeBuku = rs.getString("kode_buku");
                    String nipPegawai = rs.getString("nip_pegawai");
                    Date tanggalPinjam = rs.getDate("tanggal_pinjam");
                    Date tanggalKembali = rs.getDate("tanggal_kembali");
                    int totalPinjam = rs.getInt("total_pinjam");
                    String kondisiBuku = rs.getString("kondisi_buku");

                    System.out.println("Data arsip ditemukan: kodeAnggota=" + kodeAnggota
                            + ", kodeBuku=" + kodeBuku
                            + ", nipPegawai=" + nipPegawai
                            + ", tanggalPinjam=" + tanggalPinjam
                            + ", tanggalKembali=" + tanggalKembali
                            + ", totalPinjam=" + totalPinjam
                            + ", kondisiBuku=" + kondisiBuku);

                    // Masukkan kembali ke peminjaman
                    String sqlInsert = "INSERT INTO peminjaman "
                            + "(kode_anggota, kode_buku, nip, tanggal_pinjam, tanggal_kembali, total_pinjam, kondisi_buku) "
                            + "VALUES (?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement psInsert = conn.prepareStatement(sqlInsert)) {
                        psInsert.setString(1, kodeAnggota);
                        psInsert.setString(2, kodeBuku);
                        psInsert.setString(3, nipPegawai);
                        psInsert.setDate(4, tanggalPinjam);
                        psInsert.setDate(5, tanggalKembali);
                        psInsert.setInt(6, totalPinjam);
                        psInsert.setString(7, kondisiBuku);

                        int inserted = psInsert.executeUpdate();
                        if (inserted == 0) {
                            System.out.println("Gagal memasukkan data ke tabel peminjaman.");
                            return false;
                        } else {
                            System.out.println("Berhasil memasukkan data ke tabel peminjaman.");
                        }
                    }

                    // Hapus data dari arsip_peminjaman
                    String sqlDelete = "DELETE FROM arsip_peminjaman WHERE id_arsip = ?";
                    try (PreparedStatement psDelete = conn.prepareStatement(sqlDelete)) {
                        psDelete.setInt(1, idArsip);
                        int deleted = psDelete.executeUpdate();
                        if (deleted > 0) {
                            System.out.println("Berhasil menghapus arsip dengan id " + idArsip);
                        } else {
                            System.out.println("Gagal menghapus arsip dengan id " + idArsip);
                        }
                        return deleted > 0;
                    }
                }
            }
        } catch (SQLException ex) {
            System.out.println("Terjadi error SQL: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        }
    }

}
