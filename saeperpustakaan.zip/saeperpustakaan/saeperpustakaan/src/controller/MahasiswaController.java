package controller;

import config.Koneksi;
import model.Mahasiswa;

import java.sql.*;
import java.util.ArrayList;

public class MahasiswaController {

    // Ambil semua data mahasiswa
    public ArrayList<Mahasiswa> getAll() {
        ArrayList<Mahasiswa> list = new ArrayList<>();
        try {
            Connection conn = Koneksi.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM mahasiswa");

            while (rs.next()) {
                Mahasiswa m = new Mahasiswa(
                        rs.getInt("id_anggota"),
                        rs.getString("kode_anggota"),
                        rs.getString("nama"),
                        rs.getString("nim"),
                        rs.getString("jurusan"),
                        rs.getString("kontak"),
                        rs.getString("foto_anggota") // Tambahkan ini
                );
                list.add(m);
            }
            System.out.println("Data mahasiswa: " + list.size());
        } catch (SQLException e) {
            System.out.println("Error getAll mahasiswa: " + e.getMessage());
        }
        return list;
    }

    // Fungsi baru, dengan filter tanggal
    public ArrayList<Mahasiswa> getAllByTanggal(Date tanggalAwal, Date tanggalAkhir) {
        ArrayList<Mahasiswa> list = new ArrayList<>();
        try {
            Connection conn = Koneksi.getConnection();

            String sql = "SELECT * FROM mahasiswa WHERE tanggal_input_anggota BETWEEN ? AND ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setDate(1, new java.sql.Date(tanggalAwal.getTime()));
            pst.setDate(2, new java.sql.Date(tanggalAkhir.getTime()));

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Mahasiswa m = new Mahasiswa(
                        rs.getInt("id_anggota"),
                        rs.getString("kode_anggota"),
                        rs.getString("nama"),
                        rs.getString("nim"),
                        rs.getString("jurusan"),
                        rs.getString("kontak"),
                        rs.getString("foto_anggota") // Tambahkan ini
                );
                list.add(m);
            }
            System.out.println("Data mahasiswa dalam rentang tanggal: " + list.size());
        } catch (SQLException e) {
            System.out.println("Error getAllByTanggal mahasiswa: " + e.getMessage());
        }
        return list;
    }

    // Generate kode anggota otomatis (AGT0001, AGT0002, ...)
    public String generateKodeAnggota() {
        String kodeBaru = "AGT0001";
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "SELECT kode_anggota FROM mahasiswa ORDER BY id_anggota DESC LIMIT 1";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String lastKode = rs.getString("kode_anggota"); // contoh: AGT0021
                int nomor = Integer.parseInt(lastKode.substring(3)); // ambil 0021 -> jadi int
                nomor++; // tambah 1
                kodeBaru = String.format("AGT%04d", nomor); // AGT0022
            }
        } catch (SQLException e) {
            System.out.println("Error generateKodeAnggota: " + e.getMessage());
        }
        return kodeBaru;
    }

    // Tambah mahasiswa baru
    public void tambahMahasiswa(Mahasiswa m) {
        try {
            Connection conn = Koneksi.getConnection();
            String kodeAnggota = generateKodeAnggota(); // Panggil kode otomatis

            String sql = "INSERT INTO mahasiswa (kode_anggota, nama, nim, jurusan, kontak, foto_anggota) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, kodeAnggota); // isi otomatis
            pst.setString(2, m.getNama());
            pst.setString(3, m.getNim());
            pst.setString(4, m.getJurusan());
            pst.setString(5, m.getKontak());
            pst.setString(6, m.getFotoAnggota()); // Tambahkan ini
            pst.executeUpdate();

            System.out.println("Mahasiswa berhasil ditambah dengan kode: " + kodeAnggota);
        } catch (SQLException e) {
            System.out.println("Error tambahMahasiswa: " + e.getMessage());
        }
    }

    // Update data mahasiswa
    public void updateMahasiswa(Mahasiswa m) {
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "UPDATE mahasiswa SET kode_anggota=?, nama=?, nim=?, jurusan=?, kontak=?, foto_anggota=? WHERE id_anggota=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, m.getKodeAnggota());
            pst.setString(2, m.getNama());
            pst.setString(3, m.getNim());
            pst.setString(4, m.getJurusan());
            pst.setString(5, m.getKontak());
            pst.setString(6, m.getFotoAnggota()); // Tambahkan ini
            pst.setInt(7, m.getIdAnggota());
            pst.executeUpdate();
            System.out.println("Mahasiswa berhasil diupdate!");
        } catch (SQLException e) {
            System.out.println("Error updateMahasiswa: " + e.getMessage());
        }
    }

    // Hapus data mahasiswa
    public void deleteMahasiswa(int idAnggota) {
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "DELETE FROM mahasiswa WHERE id_anggota=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, idAnggota);
            pst.executeUpdate();
            System.out.println("Mahasiswa berhasil dihapus!");
        } catch (SQLException e) {
            System.out.println("Error deleteMahasiswa: " + e.getMessage());
        }
    }

    // Cari mahasiswa berdasarkan NIM
    public Mahasiswa getMahasiswaByNim(String nim) {
        Mahasiswa mahasiswa = null;
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "SELECT * FROM mahasiswa WHERE nim = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, nim);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                mahasiswa = new Mahasiswa(
                        rs.getInt("id_anggota"),
                        rs.getString("kode_anggota"),
                        rs.getString("nama"),
                        rs.getString("nim"),
                        rs.getString("jurusan"),
                        rs.getString("kontak"),
                        rs.getString("foto_anggota") // Tambahkan ini
                );
            }
        } catch (SQLException e) {
            System.out.println("Error getMahasiswaByNim: " + e.getMessage());
        }
        return mahasiswa;
    }
    
    public Mahasiswa getMahasiswaById(int idAnggota) {
    Mahasiswa mahasiswa = null;
    try {
        Connection conn = Koneksi.getConnection();
        String sql = "SELECT * FROM mahasiswa WHERE id_anggota = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, idAnggota);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            mahasiswa = new Mahasiswa(
                    rs.getInt("id_anggota"),
                    rs.getString("kode_anggota"),
                    rs.getString("nama"),
                    rs.getString("nim"),
                    rs.getString("jurusan"),
                    rs.getString("kontak"),
                    rs.getString("foto_anggota")
            );
        }
    } catch (SQLException e) {
        System.out.println("Error getMahasiswaById: " + e.getMessage());
    }
    return mahasiswa;
}


}
