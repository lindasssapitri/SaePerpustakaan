package controller;

import model.User;
import config.Koneksi;
import java.sql.*;
import java.util.ArrayList;

public class UserController {

    public ArrayList<User> getAll() {
        ArrayList<User> list = new ArrayList<>();
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;

        try {
            conn = Koneksi.getConnection();
            st = conn.createStatement();
            rs = st.executeQuery("SELECT id_user, id_pegawai, username, password, role FROM user");

            while (rs.next()) {
                User user = new User(
                        rs.getInt("id_user"),
                        rs.getInt("id_pegawai"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role")
                );
                list.add(user);
            }
            System.out.println("Data user: " + list.size());
        } catch (SQLException e) {
            System.out.println("Error getAll user: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    // Method untuk mengambil user berdasarkan id_pegawai
    public User getUserById(int idPegawai) {
        User user = null;
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        try {
            conn = Koneksi.getConnection();
            String sql = "SELECT id_user, username, password, role FROM user WHERE id_pegawai = ?";
            pst = conn.prepareStatement(sql);
            pst.setInt(1, idPegawai);
            rs = pst.executeQuery();
            if (rs.next()) {
                int id = rs.getInt("id_user");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String role = rs.getString("role");
                user = new User(id, idPegawai, username, password, role);
            }
        } catch (SQLException e) {
            System.out.println("Error getUserById: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return user;
    }

}
