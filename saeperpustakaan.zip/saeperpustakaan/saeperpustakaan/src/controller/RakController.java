package controller;

import config.Koneksi;
import model.Rak;

import java.sql.*;
import java.util.ArrayList;

public class RakController {

    // Ambil semua data rak
    public ArrayList<Rak> getAll() {
        ArrayList<Rak> list = new ArrayList<>();
        try {
            Connection conn = Koneksi.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM rak");

            while (rs.next()) {
                Rak r = new Rak(
                        rs.getInt("id_rak"),
                        rs.getString("kode_rak"),
                        rs.getString("nama_rak")
                );
                list.add(r);
            }
            System.out.println("Data rak: " + list.size());
        } catch (SQLException e) {
            System.out.println("Error getAll rak: " + e.getMessage());
        }
        return list;
    }

    // Tambah rak
    public void tambahRak(Rak r) {
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "INSERT INTO rak (kode_rak, nama_rak) VALUES (?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, r.getKodeRak());
            pst.setString(2, r.getNamaRak());
            pst.executeUpdate();
            System.out.println("Rak berhasil ditambah!");
        } catch (SQLException e) {
            System.out.println("Error tambahRak: " + e.getMessage());
        }
    }
    
    // Buat kode Rak
    public String generateKodeRak() {
        String kodeBaru = "RAK0001";
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "SELECT kode_rak FROM rak ORDER BY id_rak DESC LIMIT 1";
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String lastKode = rs.getString("kode_rak"); // contoh: RAK0021
                int nomor = Integer.parseInt(lastKode.substring(3)); // ambil 0021 -> jadi int
                nomor++; // tambah 1
                kodeBaru = String.format("RAK%04d", nomor); // RAK0022
            }
        } catch (SQLException e) {
            System.out.println("Error generateKodeRak: " + e.getMessage());
        }
        return kodeBaru;
    }

    // Update rak
    public void updateRak(Rak r) {
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "UPDATE rak SET kode_rak=?, nama_rak=? WHERE id_rak=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, r.getKodeRak());
            pst.setString(2, r.getNamaRak());
            pst.setInt(3, r.getIdRak());
            pst.executeUpdate();
            System.out.println("Rak berhasil diupdate!");
        } catch (SQLException e) {
            System.out.println("Error updateRak: " + e.getMessage());
        }
    }

    // Hapus rak
    public void deleteRak(int id) {
        try {
            Connection conn = Koneksi.getConnection();
            String sql = "DELETE FROM rak WHERE id_rak=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, id);
            pst.executeUpdate();
            System.out.println("Rak berhasil dihapus!");
        } catch (SQLException e) {
            System.out.println("Error deleteRak: " + e.getMessage());
        }
    }
}
