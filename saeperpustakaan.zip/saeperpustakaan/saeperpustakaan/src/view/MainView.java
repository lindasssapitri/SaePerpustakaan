package view;

import controller.BukuController;
import controller.MahasiswaController;
import controller.PegawaiController;
import controller.PeminjamanController;
import controller.ArsipPeminjamanController;
import controller.UserController;
import controller.RakController;
import model.Buku;
import model.Mahasiswa;
import model.Pegawai;
import model.Peminjaman;
import model.ArsipPeminjaman;
import model.Login;
import model.User;
import model.Rak;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.util.ArrayList;
import java.sql.Date;
import java.util.Calendar;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import javax.swing.filechooser.FileNameExtensionFilter;

public class MainView extends JFrame {

    private Login user;

    private final JButton btnBuku;
    private final JButton btnMahasiswa;
    private final JButton btnPegawai;
    private final JButton btnRak;
    private final JButton btnUser;
    private final JButton btnKembali;
    private final JTable table;
    private final DefaultTableModel model;
    private final JPanel panelAtas;
    private final JPanel panelKiri;

    private String currentView = "";
    private JFrame homeView;  // ini field class

    public MainView(Login user, JFrame homeView) {
        this.user = user;
        this.homeView = homeView;

        setTitle("Data Perpustakaan");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel Header
        JPanel panelHeader = new JPanel();
        panelHeader.setLayout(new BoxLayout(panelHeader, BoxLayout.Y_AXIS));
        panelHeader.setBackground(new Color(0, 102, 204));
        panelHeader.setBorder(BorderFactory.createEmptyBorder(60, 0, 60, 0));

        JLabel labelHeader = new JLabel("MASTER SAE PERPUSTAKAAN");
        labelHeader.setFont(new Font("Arial", Font.BOLD, 34));
        labelHeader.setForeground(Color.WHITE);
        labelHeader.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel labelSubjudul = new JLabel("Sistem Administrasi Perpustakaan Digital");
        labelSubjudul.setFont(new Font("Arial", Font.PLAIN, 16));
        labelSubjudul.setForeground(new Color(230, 230, 230));
        labelSubjudul.setAlignmentX(Component.CENTER_ALIGNMENT);

        panelHeader.add(labelHeader);
        panelHeader.add(Box.createVerticalStrut(10));
        panelHeader.add(labelSubjudul);

        // Panel Navigasi Atas
        panelAtas = new JPanel();
        panelAtas.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));
        panelAtas.setBackground(new Color(240, 240, 240));
        panelAtas.setBorder(BorderFactory.createEmptyBorder(0, 100, 0, 0));

        btnMahasiswa = new JButton("👥 Anggota");
        btnBuku = new JButton("📚 Buku");
        btnRak = new JButton("📁️️ Rak");
        btnPegawai = new JButton("👨‍💼 Pegawai");
        btnUser = new JButton("👨‍🔐 User");

        Dimension buttonSize = new Dimension(150, 40);
        JButton[] buttons = {btnMahasiswa, btnBuku, btnRak, btnPegawai, btnUser};
        for (JButton btn : buttons) {
            btn.setPreferredSize(buttonSize);
            panelAtas.add(btn);
        }

        JPanel panelUtamaAtas = new JPanel();
        panelUtamaAtas.setLayout(new BoxLayout(panelUtamaAtas, BoxLayout.Y_AXIS));
        panelUtamaAtas.add(panelHeader);
        panelUtamaAtas.add(panelAtas);
        add(panelUtamaAtas, BorderLayout.NORTH);

        // Tabel
        model = new DefaultTableModel();
        table = new JTable(model);
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(200, 200, 200));
        add(new JScrollPane(table), BorderLayout.CENTER);

        // Panel kiri untuk tombol CRUD + tombol kembali
        panelKiri = new JPanel();
        panelKiri.setLayout(new BoxLayout(panelKiri, BoxLayout.Y_AXIS));
        panelKiri.setBackground(new Color(245, 245, 245));

        JButton btnTambah = new JButton("➕ Tambah");
        JButton btnEdit = new JButton("✏️ Edit");
        JButton btnHapus = new JButton("🗑️ Hapus");
        JButton btnCetak = new JButton("📃 Cetak");
        btnKembali = new JButton("🔙 Kembali");

        btnTambah.setMaximumSize(buttonSize);
        btnEdit.setMaximumSize(buttonSize);
        btnHapus.setMaximumSize(buttonSize);
        btnCetak.setMaximumSize(buttonSize);
        btnKembali.setMaximumSize(buttonSize);

        btnTambah.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnEdit.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnHapus.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCetak.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnKembali.setAlignmentX(Component.CENTER_ALIGNMENT);

        panelKiri.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 20));
        panelKiri.add(Box.createVerticalStrut(10));
        panelKiri.add(btnTambah);
        panelKiri.add(Box.createVerticalStrut(10));
        panelKiri.add(btnEdit);
        panelKiri.add(Box.createVerticalStrut(10));
        panelKiri.add(btnHapus);
        panelKiri.add(Box.createVerticalStrut(10));
        panelKiri.add(btnCetak);
        panelKiri.add(Box.createVerticalStrut(20));
        panelKiri.add(btnKembali);
        panelKiri.add(Box.createVerticalStrut(10));

        add(panelKiri, BorderLayout.WEST);

        // Aksi tombol kembali
        btnKembali.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Apakah Anda yakin ingin kembali ke halaman utama?",
                    "Konfirmasi Kembali",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                homeView.setVisible(true);  // cukup munculkan kembali HomeView lama
                this.dispose();  // tutup TransaksiView ini
            }
        });
        
        // Atur button aktif/nonaktif sesuai role
        if (user.getRole().equalsIgnoreCase("admin")) {
            // semua aktif, jadi tidak perlu disable apa-apa
        } else if (user.getRole().equalsIgnoreCase("petugas")) {
            btnPegawai.setEnabled(false);
            btnUser.setEnabled(false);
            // anggota, buku, rak tetap aktif (btnMahasiswa, btnBuku, btnRak)
        } else {
            // role lain, misal disable semua
            for (JButton btn : buttons) {
                btn.setEnabled(false);
            }
        }

        // Aksi tombol navigasi
        btnBuku.addActionListener(e -> {
            currentView = "buku";
            tampilkanBuku();
        });

        btnMahasiswa.addActionListener(e -> {
            currentView = "mahasiswa";
            tampilkanMahasiswa();
        });

        btnPegawai.addActionListener(e -> {
            currentView = "pegawai";
            tampilkanPegawai();
        });

        btnUser.addActionListener(e -> {
            currentView = "user";
            tampilkanUser();
        });

        btnRak.addActionListener(e -> {
            currentView = "rak";
            tampilkanRak();
        });

        btnCetak.addActionListener(e -> {
            if (!"mahasiswa".equals(currentView)) {
                JOptionPane.showMessageDialog(this, "Fitur cetak hanya tersedia untuk data Anggota.", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Pilih data mahasiswa yang ingin dicetak.", "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            // Ambil id anggota dari kolom 0
            int idAnggota = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());

            // Cari mahasiswa berdasarkan id
            Mahasiswa m = new MahasiswaController().getMahasiswaById(idAnggota);

            if (m != null) {
                cetakKartuID(m);
            } else {
                JOptionPane.showMessageDialog(this, "Data mahasiswa tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        currentView = "mahasiswa";
        tampilkanMahasiswa();

        // Tombol CRUD
        // Creat
        btnTambah.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentView.equals("buku")) {
                    String kodeBukuOtomatis = new BukuController().generateKodeBuku();
                    JTextField tfKode = new JTextField(kodeBukuOtomatis);
                    tfKode.setEditable(false);

                    JTextField tfJudul = new JTextField();
                    JTextField tfPenulis = new JTextField();
                    JTextField tfPenerbit = new JTextField();
                    JTextField tfTahun = new JTextField();
                    JTextField tfStok = new JTextField("0");  // Tambahkan field stok, default 0

                    ArrayList<Rak> rakList = new RakController().getAll();
                    String[] rakOptions = rakList.stream()
                            .map(r -> r.getNamaRak() + " (" + r.getKodeRak() + ")")
                            .toArray(String[]::new);
                    JComboBox<String> cbRak = new JComboBox<>(rakOptions);

                    Object[] inputFields = {
                        "Kode Buku:", tfKode,
                        "Judul:", tfJudul,
                        "Penulis:", tfPenulis,
                        "Penerbit:", tfPenerbit,
                        "Tahun Terbit:", tfTahun,
                        "Stok Buku:", tfStok, // Tambahkan input stok
                        "Pilih Rak:", cbRak
                    };

                    int option = JOptionPane.showConfirmDialog(MainView.this, inputFields, "Tambah Buku", JOptionPane.OK_CANCEL_OPTION);
                    if (option == JOptionPane.OK_OPTION) {
                        if (tfJudul.getText().trim().isEmpty()
                                || tfPenulis.getText().trim().isEmpty()
                                || tfPenerbit.getText().trim().isEmpty()
                                || tfTahun.getText().trim().isEmpty()
                                || tfStok.getText().trim().isEmpty()) {
                            JOptionPane.showMessageDialog(MainView.this, "Semua kolom harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        int stokBuku;
                        try {
                            stokBuku = Integer.parseInt(tfStok.getText().trim());
                            if (stokBuku < 0) {
                                throw new NumberFormatException();
                            }
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(MainView.this, "Stok harus berupa angka positif!", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }

                        int selectedRakIndex = cbRak.getSelectedIndex();
                        int idRak = rakList.get(selectedRakIndex).getIdRak();

                        Buku b = new Buku(0, tfKode.getText(), tfJudul.getText(), tfPenulis.getText(),
                                tfPenerbit.getText(), tfTahun.getText(), null, null, stokBuku);

                        new BukuController().tambahBuku(b, idRak);
                        tampilkanBuku();

                        JOptionPane.showMessageDialog(MainView.this, "Buku berhasil ditambahkan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                    }
                } else if (currentView.equals("mahasiswa")) { // Menambahkan data anggota
                    boolean validInput = false;

                    // Generate kode anggota otomatis sebelum tampil form
                    String kodeAnggotaOtomatis = new MahasiswaController().generateKodeAnggota();

                    while (!validInput) {
                        JTextField tfKodeAnggota = new JTextField(kodeAnggotaOtomatis);
                        tfKodeAnggota.setEditable(false);  // Biar user tidak bisa edit kode anggota otomatis
                        JTextField tfNama = new JTextField();
                        JTextField tfNim = new JTextField();
                        JTextField tfJurusan = new JTextField();
                        JTextField tfKontak = new JTextField();

                        // Komponen untuk foto
                        JLabel labelFotoPreview = new JLabel();
                        labelFotoPreview.setPreferredSize(new Dimension(120, 150));
                        labelFotoPreview.setMinimumSize(new Dimension(120, 150));
                        labelFotoPreview.setMaximumSize(new Dimension(120, 150));

                        labelFotoPreview.setBorder(BorderFactory.createLineBorder(Color.GRAY));

                        JButton btnPilihFoto = new JButton("Pilih Foto");
                        final File[] fotoFile = {null}; // Array 1 elemen untuk menyimpan file yang dipilih

                        btnPilihFoto.addActionListener(ev -> {
                            JFileChooser fileChooser = new JFileChooser();
                            FileNameExtensionFilter filter = new FileNameExtensionFilter("Image Files", "jpg", "jpeg", "png");
                            fileChooser.setFileFilter(filter);
                            int result = fileChooser.showOpenDialog(MainView.this);
                            if (result == JFileChooser.APPROVE_OPTION) {
                                File selectedFile = fileChooser.getSelectedFile();
                                fotoFile[0] = selectedFile;
                                ImageIcon icon = new ImageIcon(selectedFile.getAbsolutePath());
                                // Resize gambar agar sesuai label preview
                                Image img = icon.getImage().getScaledInstance(labelFotoPreview.getWidth(), labelFotoPreview.getHeight(), Image.SCALE_SMOOTH);
                                labelFotoPreview.setIcon(new ImageIcon(img));
                            }
                        });

                        JPanel panelFoto = new JPanel();
                        panelFoto.setLayout(new BoxLayout(panelFoto, BoxLayout.Y_AXIS));
                        panelFoto.add(labelFotoPreview);
                        panelFoto.add(Box.createVerticalStrut(5));
                        panelFoto.add(btnPilihFoto);

                        Object[] inputFields = {
                            "Kode Anggota:", tfKodeAnggota,
                            "Nama:", tfNama,
                            "NIM:", tfNim,
                            "Jurusan:", tfJurusan,
                            "Kontak:", tfKontak,
                            "Foto Anggota:", panelFoto
                        };

                        int option = JOptionPane.showConfirmDialog(MainView.this, inputFields, "Tambah Mahasiswa", JOptionPane.OK_CANCEL_OPTION);

                        if (option == JOptionPane.OK_OPTION) {
                            // Validasi input
                            if (tfKodeAnggota.getText().trim().isEmpty()
                                    || tfNama.getText().trim().isEmpty()
                                    || tfNim.getText().trim().isEmpty()
                                    || tfJurusan.getText().trim().isEmpty()
                                    || tfKontak.getText().trim().isEmpty()) {

                                JOptionPane.showMessageDialog(MainView.this, "Semua kolom harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
                                continue; // kembali ke form
                            }

                            if (fotoFile[0] == null) {
                                int confirmNoPhoto = JOptionPane.showConfirmDialog(MainView.this,
                                        "Anda belum memilih foto anggota. Lanjutkan tanpa foto?",
                                        "Konfirmasi Foto",
                                        JOptionPane.YES_NO_OPTION);

                                if (confirmNoPhoto != JOptionPane.YES_OPTION) {
                                    continue;
                                }
                            }

                            // Default foto jika tidak ada file yang dipilih
                            String fotoAnggota = "default.jpg";

                            // Buat objek Mahasiswa dengan foto default dulu
                            Mahasiswa m = new Mahasiswa(
                                    0,
                                    tfKodeAnggota.getText().trim(),
                                    tfNama.getText().trim(),
                                    tfNim.getText().trim(),
                                    tfJurusan.getText().trim(),
                                    tfKontak.getText().trim(),
                                    fotoAnggota
                            );

                            // Update path foto jika ada foto yang dipilih
                            if (fotoFile[0] != null) {
                                m.setFotoAnggota(fotoFile[0].getAbsolutePath());
                            } else {
                                m.setFotoAnggota(null);
                            }

                            new MahasiswaController().tambahMahasiswa(m);
                            tampilkanMahasiswa();

                            validInput = true; // keluar dari loop

                            JOptionPane.showMessageDialog(MainView.this, "Anggota berhasil ditambahkan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            break;
                        }
                    }

                } else if (currentView.equals("pegawai")) {
                    boolean validInput = false;

                    String nipOtomatis = new PegawaiController().generateNip();

                    JTextField tfNip = new JTextField(nipOtomatis);
                    tfNip.setEditable(false);

                    JTextField tfNamaPegawai = new JTextField();
                    JTextField tfJabatan = new JTextField();
                    JTextField tfEmail = new JTextField();
                    JTextField tfTelepon = new JTextField();
                    JTextField tfUsername = new JTextField();
                    JPasswordField tfPassword = new JPasswordField();

                    // Dropdown untuk memilih role
                    String[] roles = {"Admin", "Petugas"};
                    JComboBox<String> cbRole = new JComboBox<>(roles);

                    while (!validInput) {
                        Object[] inputFields = {
                            "NIP:", tfNip,
                            "Nama Pegawai:", tfNamaPegawai,
                            "Jabatan:", tfJabatan,
                            "Email:", tfEmail,
                            "Telepon:", tfTelepon,
                            "Username:", tfUsername,
                            "Password:", tfPassword,
                            "Role:", cbRole
                        };

                        int option = JOptionPane.showConfirmDialog(MainView.this, inputFields, "Tambah Pegawai", JOptionPane.OK_CANCEL_OPTION);

                        if (option == JOptionPane.OK_OPTION) {
                            String nip = tfNip.getText();
                            String namaPegawai = tfNamaPegawai.getText();
                            String jabatan = tfJabatan.getText();
                            String email = tfEmail.getText();
                            String telepon = tfTelepon.getText();
                            String username = tfUsername.getText();
                            String password = new String(tfPassword.getPassword());
                            String role = (String) cbRole.getSelectedItem();

                            if (namaPegawai.isEmpty() || jabatan.isEmpty() || email.isEmpty() || telepon.isEmpty()
                                    || username.isEmpty() || password.isEmpty()) {
                                JOptionPane.showMessageDialog(MainView.this, "Semua kolom selain NIP harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
                                continue;
                            }

                            Pegawai p = new Pegawai(0, nip, namaPegawai, jabatan, email, telepon);
                            // id_pegawai diset setelah disimpan ke DB, sementara bisa isi 0
                            User u = new User(0, 0, username, password, role);

                            new PegawaiController().tambahPegawai(p, u);
                            tampilkanPegawai();

                            validInput = true;
                            JOptionPane.showMessageDialog(MainView.this, "Pegawai berhasil ditambahkan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);

                        } else {
                            break;
                        }
                    }
                } else if (currentView.equals("rak")) {
                    boolean validInput = false;

                    // Generate kode rak otomatis sebelum tampil form
                    String kodeRakOtomatis = new RakController().generateKodeRak();

                    while (!validInput) {
                        JTextField tfKodeRak = new JTextField(kodeRakOtomatis);
                        tfKodeRak.setEditable(false); // Supaya user tidak bisa edit kode rak otomatis
                        JTextField tfNamaRak = new JTextField();

                        Object[] inputFields = {
                            "Kode Rak:", tfKodeRak,
                            "Nama Rak:", tfNamaRak
                        };

                        int option = JOptionPane.showConfirmDialog(MainView.this, inputFields, "Tambah Rak", JOptionPane.OK_CANCEL_OPTION);

                        if (option == JOptionPane.OK_OPTION) {
                            // Validasi input
                            if (tfKodeRak.getText().trim().isEmpty() || tfNamaRak.getText().trim().isEmpty()) {
                                JOptionPane.showMessageDialog(MainView.this, "Semua kolom harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
                                continue; // kembali ke form input
                            }

                            // Input valid, buat objek Rak dan simpan
                            Rak r = new Rak(0, tfKodeRak.getText().trim(), tfNamaRak.getText().trim());
                            new RakController().tambahRak(r);
                            tampilkanRak(); // Pastikan method tampilkanRak() tersedia untuk refresh tabel

                            validInput = true; // keluar dari loop

                            // Pesan sukses
                            JOptionPane.showMessageDialog(MainView.this, "Rak berhasil ditambahkan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            break; // keluar jika Cancel
                        }
                    }
                }
            }
        });

        btnEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    switch (currentView) {
                        case "buku": {
                            int idBuku = (int) table.getValueAt(selectedRow, 0);
                            String kode = (String) table.getValueAt(selectedRow, 1);
                            String judul = (String) table.getValueAt(selectedRow, 2);
                            String penulis = (String) table.getValueAt(selectedRow, 3);
                            String penerbit = (String) table.getValueAt(selectedRow, 4);
                            String tahun = (String) table.getValueAt(selectedRow, 5);
                            String kodeRak = (String) table.getValueAt(selectedRow, 6);

                            // Ambil stok dari tabel (pastikan kolom stok ada di tabel dan di index 7)
                            int stok = 0;
                            try {
                                stok = Integer.parseInt(table.getValueAt(selectedRow, 8).toString());
                            } catch (Exception ex) {
                                stok = 0;
                            }

                            JTextField tfKode = new JTextField(kode);
                            JTextField tfJudul = new JTextField(judul);
                            JTextField tfPenulis = new JTextField(penulis);
                            JTextField tfPenerbit = new JTextField(penerbit);
                            JTextField tfTahun = new JTextField(tahun);
                            JTextField tfStok = new JTextField(String.valueOf(stok)); // tambah input stok

                            ArrayList<Rak> rakList = new RakController().getAll();
                            String[] rakOptions = rakList.stream()
                                    .map(r -> r.getNamaRak() + " (" + r.getKodeRak() + ")")
                                    .toArray(String[]::new);
                            JComboBox<String> cbRak = new JComboBox<>(rakOptions);

                            for (int i = 0; i < rakList.size(); i++) {
                                if (rakList.get(i).getKodeRak().equals(kodeRak)) {
                                    cbRak.setSelectedIndex(i);
                                    break;
                                }
                            }

                            Object[] inputBuku = {
                                "Kode Buku:", tfKode,
                                "Judul:", tfJudul,
                                "Penulis:", tfPenulis,
                                "Penerbit:", tfPenerbit,
                                "Tahun Terbit:", tfTahun,
                                "Stok Buku:", tfStok, // input stok
                                "Rak:", cbRak
                            };

                            int optionBuku = JOptionPane.showConfirmDialog(MainView.this, inputBuku, "Edit Buku", JOptionPane.OK_CANCEL_OPTION);
                            if (optionBuku == JOptionPane.OK_OPTION) {
                                if (tfJudul.getText().trim().isEmpty()
                                        || tfPenulis.getText().trim().isEmpty()
                                        || tfPenerbit.getText().trim().isEmpty()
                                        || tfTahun.getText().trim().isEmpty()
                                        || tfStok.getText().trim().isEmpty()) {
                                    JOptionPane.showMessageDialog(MainView.this, "Semua kolom harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }

                                int stokBuku;
                                try {
                                    stokBuku = Integer.parseInt(tfStok.getText().trim());
                                    if (stokBuku < 0) {
                                        throw new NumberFormatException();
                                    }
                                } catch (NumberFormatException ex) {
                                    JOptionPane.showMessageDialog(MainView.this, "Stok harus berupa angka positif!", "Error", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }

                                int selectedRakIndex = cbRak.getSelectedIndex();
                                int idRak = rakList.get(selectedRakIndex).getIdRak();

                                Buku b = new Buku(idBuku, tfKode.getText(), tfJudul.getText(), tfPenulis.getText(),
                                        tfPenerbit.getText(), tfTahun.getText(), null, null, stokBuku);

                                new BukuController().updateBuku(b, idRak);
                                tampilkanBuku();

                                JOptionPane.showMessageDialog(MainView.this, "Buku berhasil diupdate!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                            }
                            break;
                        }

                        case "mahasiswa": {
                            int idMhs = (int) table.getValueAt(selectedRow, 0);
                            String kodeAnggota = (String) table.getValueAt(selectedRow, 1);
                            String nama = (String) table.getValueAt(selectedRow, 2);
                            String nim = (String) table.getValueAt(selectedRow, 3);
                            String jurusan = (String) table.getValueAt(selectedRow, 4);
                            String kontak = (String) table.getValueAt(selectedRow, 5);
                            String fotoAnggota = (String) table.getValueAt(selectedRow, 6); // pastikan kolom ke-7 adalah foto

                            // Komponen form
                            JTextField tfKodeAnggota = new JTextField(kodeAnggota);
                            tfKodeAnggota.setEditable(false); // kode anggota tidak bisa diedit
                            JTextField tfNama = new JTextField(nama);
                            JTextField tfNim = new JTextField(nim);
                            JTextField tfJurusan = new JTextField(jurusan);
                            JTextField tfKontak = new JTextField(kontak);

                            // Komponen untuk foto
                            JLabel labelFotoPreview = new JLabel();
                            labelFotoPreview.setPreferredSize(new Dimension(120, 150));
                            labelFotoPreview.setBorder(BorderFactory.createLineBorder(Color.GRAY));

                            final File[] fotoFile = {null}; // untuk menyimpan file yang dipilih user

                            // Tampilkan foto lama kalau ada
                            if (fotoAnggota != null && !fotoAnggota.trim().isEmpty()) {
                                ImageIcon icon = new ImageIcon(fotoAnggota);
                                Dimension size = labelFotoPreview.getPreferredSize();
                                Image img = icon.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
                                labelFotoPreview.setIcon(new ImageIcon(img));
                            }

                            JButton btnPilihFoto = new JButton("Pilih Foto");
                            btnPilihFoto.addActionListener(ev -> {
                                JFileChooser fileChooser = new JFileChooser();
                                FileNameExtensionFilter filter = new FileNameExtensionFilter("Image Files", "jpg", "jpeg", "png");
                                fileChooser.setFileFilter(filter);
                                int result = fileChooser.showOpenDialog(MainView.this);
                                if (result == JFileChooser.APPROVE_OPTION) {
                                    File selectedFile = fileChooser.getSelectedFile();
                                    fotoFile[0] = selectedFile;
                                    ImageIcon icon = new ImageIcon(selectedFile.getAbsolutePath());
                                    Dimension size = labelFotoPreview.getPreferredSize();
                                    Image img = icon.getImage().getScaledInstance(size.width, size.height, Image.SCALE_SMOOTH);
                                    labelFotoPreview.setIcon(new ImageIcon(img));
                                }
                            });

                            JPanel panelFoto = new JPanel();
                            panelFoto.setLayout(new BoxLayout(panelFoto, BoxLayout.Y_AXIS));
                            panelFoto.add(labelFotoPreview);
                            panelFoto.add(Box.createVerticalStrut(5));
                            panelFoto.add(btnPilihFoto);

                            Object[] inputMhs = {
                                "Kode Anggota:", tfKodeAnggota,
                                "Nama:", tfNama,
                                "NIM:", tfNim,
                                "Jurusan:", tfJurusan,
                                "Kontak:", tfKontak,
                                "Foto Anggota:", panelFoto
                            };

                            int optionMhs = JOptionPane.showConfirmDialog(MainView.this, inputMhs, "Edit Mahasiswa", JOptionPane.OK_CANCEL_OPTION);

                            if (optionMhs == JOptionPane.OK_OPTION) {
                                // Validasi input
                                if (tfNama.getText().trim().isEmpty()
                                        || tfNim.getText().trim().isEmpty()
                                        || tfJurusan.getText().trim().isEmpty()
                                        || tfKontak.getText().trim().isEmpty()) {

                                    JOptionPane.showMessageDialog(MainView.this, "Semua kolom harus diisi!", "Error", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }

                                // Siapkan objek Mahasiswa
                                Mahasiswa m = new Mahasiswa(
                                        idMhs,
                                        tfKodeAnggota.getText().trim(),
                                        tfNama.getText().trim(),
                                        tfNim.getText().trim(),
                                        tfJurusan.getText().trim(),
                                        tfKontak.getText().trim(),
                                        fotoAnggota // default tetap foto lama
                                );

                                // Kalau user pilih foto baru, update fotoAnggota
                                if (fotoFile[0] != null) {
                                    m.setFotoAnggota(fotoFile[0].getAbsolutePath());
                                }

                                new MahasiswaController().updateMahasiswa(m);
                                tampilkanMahasiswa();

                                JOptionPane.showMessageDialog(MainView.this, "Data mahasiswa berhasil diperbarui!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                            }
                            break;
                        }

                        case "pegawai": {
                            int idPegawai = (int) table.getValueAt(selectedRow, 0);
                            String nip = (String) table.getValueAt(selectedRow, 1);
                            String namaPegawai = (String) table.getValueAt(selectedRow, 2);
                            String jabatan = (String) table.getValueAt(selectedRow, 3);
                            String email = (String) table.getValueAt(selectedRow, 4);
                            String telepon = (String) table.getValueAt(selectedRow, 5);

                            User u = new UserController().getUserById(idPegawai);
                            String username = u != null ? u.getUsername() : "";
                            String password = u != null ? u.getPassword() : "";
                            String role = u != null ? u.getRole() : "Petugas"; // Default role jika belum ada

                            JTextField tfNip = new JTextField(nip);
                            JTextField tfNamaPegawai = new JTextField(namaPegawai);
                            JTextField tfJabatan = new JTextField(jabatan);
                            JTextField tfEmail = new JTextField(email);
                            JTextField tfTelepon = new JTextField(telepon);
                            JTextField tfUsername = new JTextField(username);
                            JPasswordField pfPassword = new JPasswordField(password);

                            // Tambahkan pilihan role
                            String[] roleOptions = {"Admin", "Petugas"};
                            JComboBox<String> cbRole = new JComboBox<>(roleOptions);
                            cbRole.setSelectedItem(role); // Set default dari database

                            Object[] inputPegawai = {
                                "NIP:", tfNip,
                                "Nama Pegawai:", tfNamaPegawai,
                                "Jabatan:", tfJabatan,
                                "Email:", tfEmail,
                                "Telepon:", tfTelepon,
                                "Username:", tfUsername,
                                "Password:", pfPassword,
                                "Role:", cbRole
                            };

                            int optionPegawai = JOptionPane.showConfirmDialog(null, inputPegawai, "Edit Pegawai", JOptionPane.OK_CANCEL_OPTION);
                            if (optionPegawai == JOptionPane.OK_OPTION) {
                                Pegawai p = new Pegawai(idPegawai, tfNip.getText(), tfNamaPegawai.getText(), tfJabatan.getText(), tfEmail.getText(), tfTelepon.getText());

                                // Pastikan mengambil id_user dari hasil getUserById, jika tidak null
                                int idUser = u != null ? u.getIdUser() : 0;

                                User user = new User(
                                        idUser,
                                        idPegawai,
                                        tfUsername.getText(),
                                        new String(pfPassword.getPassword()),
                                        (String) cbRole.getSelectedItem()
                                );

                                new PegawaiController().updatePegawai(p, user);
                                tampilkanPegawai();
                            }
                            break;
                        }

                        case "rak": {
                            int idRak = (int) table.getValueAt(selectedRow, 0);
                            String kodeRak = (String) table.getValueAt(selectedRow, 1);
                            String namaRak = (String) table.getValueAt(selectedRow, 2);

                            JTextField tfKodeRak = new JTextField(kodeRak);
                            JTextField tfNamaRak = new JTextField(namaRak);

                            Object[] inputRak = {
                                "Kode Rak:", tfKodeRak,
                                "Nama Rak:", tfNamaRak
                            };

                            int optionRak = JOptionPane.showConfirmDialog(MainView.this, inputRak, "Edit Rak", JOptionPane.OK_CANCEL_OPTION);
                            if (optionRak == JOptionPane.OK_OPTION) {
                                Rak r = new Rak(idRak, tfKodeRak.getText().trim(), tfNamaRak.getText().trim());
                                new RakController().updateRak(r);
                                tampilkanRak(); // fungsi untuk refresh data rak di table
                                JOptionPane.showMessageDialog(MainView.this, "Rak berhasil diupdate!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                            }
                            break;
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(MainView.this, "Pilih baris terlebih dahulu untuk diedit.");
                }
            }
        });

        btnHapus.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int confirm = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    int id = (int) table.getValueAt(selectedRow, 0);
                    switch (currentView) {
                        case "buku":
                            new BukuController().deleteBuku(id);
                            tampilkanBuku();
                            break;
                        case "mahasiswa":
                            new MahasiswaController().deleteMahasiswa(id);
                            tampilkanMahasiswa();
                            break;
                        case "pegawai":
                            new PegawaiController().deletePegawai(id);
                            tampilkanPegawai();
                            break;
                        case "rak":
                            new RakController().deleteRak(id);
                            tampilkanRak();
                            break;
                        case "peminjaman":
                            new PeminjamanController().deletePeminjaman(id);
                            tampilkanPeminjaman();
                            break;
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Pilih baris terlebih dahulu yang ingin dihapus.");
            }
        });

    }

    // Cetak Kartu ID Preview
    private void cetakKartuID(Mahasiswa m) {
        // Panel kartu ID utama
        JPanel kartuPanel = new JPanel();
        kartuPanel.setPreferredSize(new Dimension(410, 250));
        kartuPanel.setBackground(Color.WHITE);
        kartuPanel.setBorder(BorderFactory.createLineBorder(new Color(0, 51, 102), 3)); // border biru tua
        kartuPanel.setLayout(new BorderLayout());

        // --- HEADER ---
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(0, 51, 102)); // biru tua perpustakaan
        headerPanel.setPreferredSize(new Dimension(360, 40));
        headerPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, Color.WHITE)); // garis bawah putih

        JLabel lblPerpus = new JLabel("Sae Perpustakaan");
        lblPerpus.setForeground(Color.WHITE);
        lblPerpus.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblPerpus.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 0));

        // Placeholder logo kecil (ganti dengan ImageIcon jika ada)
        JLabel lblLogo = new JLabel("📚");
        lblLogo.setForeground(Color.WHITE);
        lblLogo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24));
        lblLogo.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 15));

        headerPanel.add(lblPerpus, BorderLayout.WEST);
        headerPanel.add(lblLogo, BorderLayout.EAST);

        kartuPanel.add(headerPanel, BorderLayout.NORTH);
        kartuPanel.revalidate();
        kartuPanel.repaint();

        // --- BAGIAN FOTO DAN INFO ---
        JPanel bodyPanel = new JPanel(new BorderLayout());
        bodyPanel.setBackground(Color.WHITE);
        bodyPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Foto anggota
        JLabel labelFoto = new JLabel();
        labelFoto.setPreferredSize(new Dimension(110, 170));
        labelFoto.setHorizontalAlignment(JLabel.CENTER);
        labelFoto.setVerticalAlignment(JLabel.CENTER);

        // Border bulat untuk foto
        labelFoto.setBorder(BorderFactory.createLineBorder(new Color(0, 51, 102), 2));

        if (m.getFotoAnggota() != null && !m.getFotoAnggota().isEmpty()) {
            ImageIcon icon = new ImageIcon(m.getFotoAnggota());
            Image img = icon.getImage().getScaledInstance(110, 170, Image.SCALE_SMOOTH);
            labelFoto.setIcon(new ImageIcon(img));
            labelFoto.setText(null);
        } else {
            labelFoto.setText("<html><center>No<br>Photo</center></html>");
            labelFoto.setFont(new Font("Segoe UI", Font.ITALIC, 14));
            labelFoto.setForeground(Color.GRAY);
        }

        // Panel foto dengan sedikit padding
        JPanel panelFoto = new JPanel(new BorderLayout());
        panelFoto.setBackground(Color.WHITE);
        panelFoto.add(labelFoto, BorderLayout.CENTER);
        panelFoto.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 15)); // margin kanan

        bodyPanel.add(panelFoto, BorderLayout.WEST);

        // Panel info dengan GridBagLayout
        JPanel infoPanel = new JPanel(new GridBagLayout());
        infoPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(6, 6, 6, 6);

        Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
        Font valueFont = new Font("Segoe UI", Font.PLAIN, 14);
        Color labelColor = new Color(0, 51, 102); // biru tua

        // Baris 1 - Kode Anggota
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel lblKode = new JLabel("Kode Anggota:");
        lblKode.setFont(labelFont);
        lblKode.setForeground(labelColor);
        infoPanel.add(lblKode, gbc);

        gbc.gridx = 1;
        JLabel valKode = new JLabel(m.getKodeAnggota());
        valKode.setFont(valueFont);
        infoPanel.add(valKode, gbc);

        // Baris 2 - Nama
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel lblNama = new JLabel("Nama:");
        lblNama.setFont(labelFont);
        lblNama.setForeground(labelColor);
        infoPanel.add(lblNama, gbc);

        gbc.gridx = 1;
        JLabel valNama = new JLabel(m.getNama());
        valNama.setFont(valueFont);
        infoPanel.add(valNama, gbc);

        // Baris 3 - NIM
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel lblNim = new JLabel("NIM:");
        lblNim.setFont(labelFont);
        lblNim.setForeground(labelColor);
        infoPanel.add(lblNim, gbc);

        gbc.gridx = 1;
        JLabel valNim = new JLabel(m.getNim());
        valNim.setFont(valueFont);
        infoPanel.add(valNim, gbc);

        // Baris 4 - Jurusan
        gbc.gridx = 0;
        gbc.gridy++;
        JLabel lblJurusan = new JLabel("Jurusan:");
        lblJurusan.setFont(labelFont);
        lblJurusan.setForeground(labelColor);
        infoPanel.add(lblJurusan, gbc);

        gbc.gridx = 1;
        JLabel valJurusan = new JLabel(m.getJurusan());
        valJurusan.setFont(valueFont);
        infoPanel.add(valJurusan, gbc);

        bodyPanel.add(infoPanel, BorderLayout.CENTER);

        kartuPanel.add(bodyPanel, BorderLayout.CENTER);

        // --- FOOTER (opsional) ---
        // Bisa ditambahkan info tambahan seperti tanggal berlaku, barcode, dll.
        // Dialog tampilkan kartu
        int option = JOptionPane.showConfirmDialog(
                this, kartuPanel, "Preview Kartu Anggota Perpustakaan", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE
        );

        if (option == JOptionPane.OK_OPTION) {
            try {
                printComponent(kartuPanel);
            } catch (PrinterException ex) {
                JOptionPane.showMessageDialog(this, "Gagal mencetak: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Cetak Kartu ID PDF
    private void printComponent(JPanel panel) throws PrinterException {
        PrinterJob pj = PrinterJob.getPrinterJob();
        pj.setJobName("Cetak Kartu ID");

        double kartuWidthInch = 4.0;
        double kartuHeightInch = 2.126;

        int kartuWidthPoints = (int) (kartuWidthInch * 72);
        int kartuHeightPoints = (int) (kartuHeightInch * 72);

        pj.setPrintable((graphics, pageFormat, pageIndex) -> {
            if (pageIndex > 0) {
                return Printable.NO_SUCH_PAGE;
            }

            Graphics2D g2 = (Graphics2D) graphics;

            double printableWidth = pageFormat.getImageableWidth();

            double scaleX = kartuWidthPoints / (double) panel.getWidth();
            double scaleY = kartuHeightPoints / (double) panel.getHeight();
            double scale = Math.min(scaleX, scaleY);

            // Jarak dari atas (margin atas)
            double topMargin = 40; // poin

            // Posisi x: tengah horizontal
            double x = pageFormat.getImageableX() + (printableWidth - kartuWidthPoints * scale) / 2.0;
            // Posisi y: ada jarak dari atas
            double y = pageFormat.getImageableY() + topMargin;

            g2.translate(x, y);
            g2.scale(scale, scale);

            panel.printAll(g2);

            return Printable.PAGE_EXISTS;
        });

        if (pj.printDialog()) {
            pj.print();
        }
    }

    // Menampilkan data buku
    private void tampilkanBuku() {
        model.setColumnIdentifiers(new Object[]{
            "ID", "Kode Buku", "Judul", "Penulis", "Penerbit", "Tahun", "Kode Rak", "Nama Rak", "Stok"
        });
        model.setRowCount(0); // Bersihkan tabel sebelum isi ulang

        ArrayList<Buku> list = new BukuController().getAll();
        for (Buku b : list) {
            model.addRow(new Object[]{
                b.getId(), b.getKodeBuku(), b.getJudul(),
                b.getPenulis(), b.getPenerbit(), b.getTahun(),
                b.getKodeRak(), b.getNamaRak(), b.getStokBuku()
            });
        }
    }

    // Menampilkan data mahasiswa
    private void tampilkanMahasiswa() {
        model.setColumnIdentifiers(new Object[]{"ID", "Kode Anggota", "Nama", "NIM", "Jurusan", "Kontak", "Foto Anggota"});
        model.setRowCount(0);

        ArrayList<Mahasiswa> list = new MahasiswaController().getAll();
        for (Mahasiswa m : list) {
            model.addRow(new Object[]{
                m.getIdAnggota(),
                m.getKodeAnggota(),
                m.getNama(),
                m.getNim(),
                m.getJurusan(),
                m.getKontak(),
                m.getFotoAnggota() // Tambahkan ini
            });
        }
    }

    // Menampilkan data Pegawai
    private void tampilkanPegawai() {
        model.setColumnIdentifiers(new Object[]{"ID", "NIP", "Nama", "Jabatan", "Email", "Telepon"});
        model.setRowCount(0);
        ArrayList<Pegawai> list = new PegawaiController().getAll();
        for (Pegawai p : list) {
            model.addRow(new Object[]{
                p.getId(), p.getNip(), p.getNama(), p.getJabatan(),
                p.getEmail(), p.getTelepon() // Menambahkan NIP ke dalam tabel
            });
        }
    }

    // Fungsi untuk menampilkan data user ke dalam table model
    private void tampilkanUser() {
        model.setColumnIdentifiers(new Object[]{"ID User", "ID Pegawai", "Username", "Role"});
        model.setRowCount(0);

        ArrayList<User> list = new UserController().getAll();
        for (User u : list) {
            model.addRow(new Object[]{
                u.getIdUser(),
                u.getIdPegawai(),
                u.getUsername(),
                u.getRole()
            });
        }
    }

    // Menampilkan data Rak
    private void tampilkanRak() {
        model.setColumnIdentifiers(new Object[]{"ID", "Kode Rak", "Nama Rak"});
        model.setRowCount(0);
        ArrayList<Rak> list = new RakController().getAll();
        for (Rak r : list) {
            model.addRow(new Object[]{
                r.getIdRak(), r.getKodeRak(), r.getNamaRak()
            });
        }
    }

    private void tampilkanPeminjaman() {
        model.setColumnIdentifiers(new Object[]{
            "ID Peminjaman", "Kode Anggota", "Nama Anggota", "Kode Buku", "NIP Pegawai", "Tanggal Pinjam", "Tanggal Kembali"
        });
        model.setRowCount(0);
        ArrayList<Peminjaman> list = new PeminjamanController().getAll();
        for (Peminjaman p : list) {
            model.addRow(new Object[]{
                p.getIdPeminjaman(),
                p.getKodeAnggota(),
                p.getNamaAnggota(),
                p.getKodeBuku(),
                p.getNip(),
                p.getTanggalPinjam(),
                p.getTanggalKembali()
            });
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
