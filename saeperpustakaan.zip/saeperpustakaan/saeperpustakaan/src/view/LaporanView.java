package view;

import controller.BukuController;
import controller.MahasiswaController;
import controller.PegawaiController;
import controller.PeminjamanController;
import controller.ArsipPeminjamanController;
import controller.UserController;
import controller.RakController;
import controller.LoginController;
import controller.LaporanController;
import model.Buku;
import model.Mahasiswa;
import model.Pegawai;
import model.Peminjaman;
import model.ArsipPeminjaman;
import model.User;
import model.Rak;
import model.Login;
import model.Laporan;
import view.HomeView;
import view.LoginView;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.sql.Date;
import java.util.Vector;
import javax.swing.Timer;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import javax.swing.border.EmptyBorder;

public class LaporanView extends JFrame {
    
    private Login user;
    private JFrame homeView;
    
    private JPanel panelAtas;
    private JPanel panelKiri;
    private JButton btnKembali;

    private JButton btnJumlahBuku;
    private JButton btnJumlahMahasiswa;
    private JButton btnJumlahPegawai;
    private JButton btnTotalPeminjaman;
    private JButton btnJumlahArsipPengembalian;
    private JButton btnTotalDenda;

    // Komponen baru untuk filter tanggal
    private JLabel lblTanggalAwal;
    private JLabel lblTanggalAkhir;
    private JSpinner spinnerTanggalAwal;
    private JSpinner spinnerTanggalAkhir;
    private JButton btnFilter;

    private JTable table;
    private DefaultTableModel model;
    private String currentView = "";

    public LaporanView(Login user, JFrame homeView) {
        this.user = user;
        this.homeView = homeView;
        
        setTitle("Data Perpustakaan");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);  // penting!
        setLocationRelativeTo(null);

        // Panel Header
        JPanel panelHeader = new JPanel();
        panelHeader.setLayout(new BoxLayout(panelHeader, BoxLayout.Y_AXIS));
        panelHeader.setBackground(new Color(0, 102, 204));
        panelHeader.setBorder(BorderFactory.createEmptyBorder(60, 0, 60, 0));

        JLabel labelHeader = new JLabel("LAPORAN SAE PERPUSTAKAAN");
        labelHeader.setFont(new Font("Arial", Font.BOLD, 34));
        labelHeader.setForeground(Color.WHITE);
        labelHeader.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel labelSubjudul = new JLabel("Sistem Administrasi Perpustakaan Digital");
        labelSubjudul.setFont(new Font("Arial", Font.PLAIN, 16));
        labelSubjudul.setForeground(new Color(230, 230, 230));
        labelSubjudul.setAlignmentX(Component.CENTER_ALIGNMENT);

        panelHeader.add(labelHeader);
        panelHeader.add(Box.createVerticalStrut(10));
        panelHeader.add(labelSubjudul);

        // Panel Navigasi Atas
        panelAtas = new JPanel();
        panelAtas.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));
        panelAtas.setBackground(new Color(240, 240, 240));
        panelAtas.setBorder(BorderFactory.createEmptyBorder(0, 100, 0, 0));

        // Panel data laporan tombol (1 baris 6 kolom)
        JPanel panelDataLaporan = new JPanel();
        panelDataLaporan.setLayout(new GridLayout(1, 6, 20, 0));
        panelDataLaporan.setBackground(new Color(240, 240, 240));
        panelDataLaporan.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        Dimension btnSize = new Dimension(160, 80);

        btnJumlahBuku = createDataButton("Jumlah Buku", "-", btnSize);
        btnJumlahMahasiswa = createDataButton("Jumlah Anggota", "-", btnSize);
        btnJumlahPegawai = createDataButton("Jumlah Pegawai", "-", btnSize);
        btnTotalPeminjaman = createDataButton("Total Peminjaman", "-", btnSize);
        btnJumlahArsipPengembalian = createDataButton("Jumlah Arsip Pengembalian", "-", btnSize);
        btnTotalDenda = createDataButton("Total Denda", "-", btnSize);

        panelDataLaporan.add(btnJumlahBuku);
        panelDataLaporan.add(btnJumlahMahasiswa);
        panelDataLaporan.add(btnJumlahPegawai);
        panelDataLaporan.add(btnTotalPeminjaman);
        panelDataLaporan.add(btnJumlahArsipPengembalian);
        panelDataLaporan.add(btnTotalDenda);

        panelAtas.add(panelDataLaporan);

        // Panel utama atas gabungkan header + navigasi atas
        JPanel panelUtamaAtas = new JPanel();
        panelUtamaAtas.setLayout(new BoxLayout(panelUtamaAtas, BoxLayout.Y_AXIS));
        panelUtamaAtas.add(panelHeader);
        panelUtamaAtas.add(panelAtas);
        add(panelUtamaAtas, BorderLayout.NORTH);

        // Tabel
        model = new DefaultTableModel();
        table = new JTable(model);
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(200, 200, 200));
        add(new JScrollPane(table), BorderLayout.CENTER);

        // Panel kiri untuk tombol CRUD + tombol kembali
        panelKiri = new JPanel();
        panelKiri.setLayout(new BoxLayout(panelKiri, BoxLayout.Y_AXIS));
        panelKiri.setBackground(new Color(245, 245, 245));
        panelKiri.setBorder(new EmptyBorder(10, 10, 10, 20));

        // Label dan Spinner tanggal awal
        lblTanggalAwal = new JLabel("Tanggal Awal:");
        spinnerTanggalAwal = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor dateEditorAwal = new JSpinner.DateEditor(spinnerTanggalAwal, "dd-MM-yyyy");
        spinnerTanggalAwal.setEditor(dateEditorAwal);
        spinnerTanggalAwal.setMaximumSize(new Dimension(150, 30));

        // Label dan Spinner tanggal akhir
        lblTanggalAkhir = new JLabel("Tanggal Akhir:");
        spinnerTanggalAkhir = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor dateEditorAkhir = new JSpinner.DateEditor(spinnerTanggalAkhir, "dd-MM-yyyy");
        spinnerTanggalAkhir.setEditor(dateEditorAkhir);
        spinnerTanggalAkhir.setMaximumSize(new Dimension(150, 30));

        // Tombol Filter
        btnFilter = new JButton("🔍 Filter");
        btnFilter.setMaximumSize(new Dimension(150, 40));
        btnFilter.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Tombol Kembali (tetap ada)
        btnKembali = new JButton("🔙 Kembali");
        btnKembali.setMaximumSize(new Dimension(150, 40));
        btnKembali.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Tambahkan ke panel kiri dengan spacing
        panelKiri.add(lblTanggalAwal);
        panelKiri.add(Box.createVerticalStrut(5));
        panelKiri.add(spinnerTanggalAwal);
        panelKiri.add(Box.createVerticalStrut(15));
        panelKiri.add(lblTanggalAkhir);
        panelKiri.add(Box.createVerticalStrut(5));
        panelKiri.add(spinnerTanggalAkhir);
        panelKiri.add(Box.createVerticalStrut(20));
        panelKiri.add(btnFilter);
        panelKiri.add(Box.createVerticalStrut(30));
        panelKiri.add(btnKembali);
        panelKiri.add(Box.createVerticalStrut(10));

        add(panelKiri, BorderLayout.WEST);

        // Tampilkan data laporan awal
        tampilkanLaporan();
        tampilkanBuku();

        setVisible(true);
        // Aksi tombol navigasi
        btnJumlahBuku.addActionListener(e -> {
            currentView = "buku";
            tampilkanBuku();
        });

        btnJumlahMahasiswa.addActionListener(e -> {
            currentView = "mahasiswa";
            tampilkanMahasiswa();
        });

        btnJumlahPegawai.addActionListener(e -> {
            currentView = "pegawai";
            tampilkanPegawai();
        });

        btnTotalPeminjaman.addActionListener(e -> {
            currentView = "peminjaman";
            tampilkanPeminjaman();
        });

        btnJumlahArsipPengembalian.addActionListener(e -> {
            currentView = "arsip";
            tampilkanArsip();
        });

        btnTotalDenda.addActionListener(e -> {
            currentView = "denda";
            //tampilkanArsip();
            tampilkanArsip();
        });

        // Aksi tombol kembali
        btnKembali.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Apakah Anda yakin ingin kembali ke halaman utama?",
                    "Konfirmasi Kembali",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                homeView.setVisible(true);  // cukup munculkan kembali HomeView lama
                this.dispose();  // tutup TransaksiView ini
            }
        });

        // Aksi tombol Filter
        btnFilter.addActionListener(e -> {
            try {
                // Ambil tanggal dari spinner
                java.util.Date tanggalAwalUtil = (java.util.Date) spinnerTanggalAwal.getValue();
                java.util.Date tanggalAkhirUtil = (java.util.Date) spinnerTanggalAkhir.getValue();

                // Validasi tanggal
                if (tanggalAwalUtil.after(tanggalAkhirUtil)) {
                    JOptionPane.showMessageDialog(this, "Tanggal awal tidak boleh lebih besar dari tanggal akhir.");
                    return;
                }

                // Konversi ke java.sql.Date
                java.sql.Date tanggalAwal = new java.sql.Date(tanggalAwalUtil.getTime());
                java.sql.Date tanggalAkhir = new java.sql.Date(tanggalAkhirUtil.getTime());

                if (currentView.equals("buku")) {
                    // Ambil data buku dengan filter tanggal
                    ArrayList<Buku> list = new BukuController().getAll(tanggalAwal, tanggalAkhir);

                    // Set header tabel untuk buku
                    model.setColumnIdentifiers(new Object[]{
                        "ID", "Kode Buku", "Judul", "Penulis", "Penerbit", "Tahun", "Kode Rak", "Nama Rak", "Stok"
                    });
                    model.setRowCount(0); // Bersihkan tabel

                    for (Buku b : list) {
                        model.addRow(new Object[]{
                            b.getId(), b.getKodeBuku(), b.getJudul(),
                            b.getPenulis(), b.getPenerbit(), b.getTahun(),
                            b.getKodeRak(), b.getNamaRak(), b.getStokBuku()
                        });
                    }

                    JOptionPane.showMessageDialog(this, "Filter berhasil diterapkan: " + list.size() + " data buku ditemukan.");

                } else if (currentView.equals("mahasiswa")) {
                    // Ambil data mahasiswa dengan filter tanggal
                    ArrayList<Mahasiswa> list = new MahasiswaController().getAllByTanggal(tanggalAwal, tanggalAkhir);

                    // Set header tabel untuk mahasiswa
                    model.setColumnIdentifiers(new Object[]{
                        "ID", "Kode Anggota", "Nama", "NIM", "Jurusan", "Kontak"
                    });
                    model.setRowCount(0); // Bersihkan tabel

                    for (Mahasiswa m : list) {
                        model.addRow(new Object[]{
                            m.getIdAnggota(), m.getKodeAnggota(), m.getNama(), m.getNim(), m.getJurusan(), m.getKontak()
                        });
                    }

                    JOptionPane.showMessageDialog(this, "Filter berhasil diterapkan: " + list.size() + " data mahasiswa ditemukan.");

                } else if (currentView.equals("pegawai")) {
                    // Ambil data pegawai dengan filter tanggal
                    ArrayList<Pegawai> list = new PegawaiController().getAllByTanggal(tanggalAwal, tanggalAkhir);

                    // Set header tabel untuk pegawai
                    model.setColumnIdentifiers(new Object[]{
                        "ID", "NIP", "Nama", "Jabatan", "Email", "Telepon"
                    });
                    model.setRowCount(0); // Bersihkan tabel

                    for (Pegawai p : list) {
                        model.addRow(new Object[]{
                            p.getId(), p.getNip(), p.getNama(), p.getJabatan(), p.getEmail(), p.getTelepon()
                        });
                    }

                    JOptionPane.showMessageDialog(this, "Filter berhasil diterapkan: " + list.size() + " data pegawai ditemukan.");

                } else if (currentView.equals("peminjaman")) {
                    // Ambil data peminjaman dengan filter tanggal
                    ArrayList<Peminjaman> list = new PeminjamanController().getAll(tanggalAwal, tanggalAkhir);

                    // Set header tabel untuk peminjaman
                    model.setColumnIdentifiers(new Object[]{
                        "ID Peminjaman", "Kode Buku", "Kode Anggota", "Nama", "NIP", "Tanggal Pinjam", "Tanggal Kembali", "Total Pinjam"
                    });
                    model.setRowCount(0); // Bersihkan tabel

                    for (Peminjaman p : list) {
                        model.addRow(new Object[]{
                            p.getIdPeminjaman(), p.getKodeBuku(), p.getKodeAnggota(),
                            p.getNamaAnggota(), p.getNip(),
                            p.getTanggalPinjam(), p.getTanggalKembali(),
                            p.getTotalPinjam()
                        });
                    }

                    JOptionPane.showMessageDialog(this, "Filter berhasil diterapkan: " + list.size() + " data peminjaman ditemukan.");

                } else if (currentView.equals("arsip")) {
                    // Filter arsip peminjaman berdasarkan tanggal_input_arsip
                    ArrayList<ArsipPeminjaman> list = new ArsipPeminjamanController().getAllArsip(tanggalAwal, tanggalAkhir);

                    model.setColumnIdentifiers(new Object[]{
                        "ID Arsip", "Kode Anggota", "Kode Buku", "NIP Pegawai", "Tanggal Pinjam", "Tanggal Kembali",
                        "Tanggal Pengembalian", "Total Pinjam", "Kondisi Buku", "Total Denda"
                    });
                    model.setRowCount(0);

                    for (ArsipPeminjaman a : list) {
                        model.addRow(new Object[]{
                            a.getIdArsip(),
                            a.getKodeAnggota(),
                            a.getKodeBuku(),
                            a.getNipPegawai(),
                            a.getTanggalPinjam(),
                            a.getTanggalKembali(),
                            a.getTanggalPengembalian(),
                            a.getTotalPinjam(),
                            a.getKondisiBuku(),
                            a.getTotalDenda()
                        });
                    }

                    JOptionPane.showMessageDialog(this, "Filter berhasil diterapkan: " + list.size() + " data arsip peminjaman ditemukan.");
                } else if (currentView.equals("denda")) {
                    tampilkanTotalDenda();
                } else {
                    JOptionPane.showMessageDialog(this, "Filter tanggal hanya berlaku untuk data Buku, Mahasiswa, Pegawai, Peminjaman, atau Arsip Peminjaman.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat memfilter data: " + ex.getMessage());
            }
        });

    }

    // Membuat tombol data dengan label kecil + nilai besar (2 baris)
    private JButton createDataButton(String label, String value, Dimension size) {
        String htmlText = "<html><center><small style='color:#555555;'>" + label + "</small><br>"
                + "<span style='font-size:18pt; font-weight:bold; color:#003366;'>" + value + "</span></center></html>";

        JButton button = new JButton(htmlText);
        button.setPreferredSize(size);
        button.setFocusPainted(false);
        button.setContentAreaFilled(true);
        button.setOpaque(true);
        button.setBackground(new Color(220, 235, 255));  // Latar biru muda lembut
        button.setForeground(new Color(0, 51, 102));     // Warna teks utama (gelap biru)

        // Border dengan warna biru tua dan sudut membulat
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0, 102, 204), 2, true),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        // Hover effect sederhana (ubah warna latar saat mouse over)
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(180, 210, 255));
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(220, 235, 255));
                button.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            }
        });

        return button;

    }

    // Update teks tombol data dengan format HTML
    private void updateButtonText(JButton button, String label, String value) {
        String htmlText = "<html><center><small>" + label + "</small><br>"
                + "<span style='font-size:18pt; font-weight:bold;'>" + value + "</span></center></html>";
        button.setText(htmlText);
    }

    // Menampilkan data buku
    private void tampilkanBuku() {
        model.setColumnIdentifiers(new Object[]{
            "ID", "Kode Buku", "Judul", "Penulis", "Penerbit", "Tahun", "Kode Rak", "Nama Rak", "Stok"
        });
        model.setRowCount(0); // Bersihkan tabel sebelum isi ulang

        ArrayList<Buku> list = new BukuController().getAll();
        for (Buku b : list) {
            model.addRow(new Object[]{
                b.getId(), b.getKodeBuku(), b.getJudul(),
                b.getPenulis(), b.getPenerbit(), b.getTahun(),
                b.getKodeRak(), b.getNamaRak(), b.getStokBuku()
            });
        }
    }

    // Menampilkan data mahasiswa
    private void tampilkanMahasiswa() {
        model.setColumnIdentifiers(new Object[]{"ID", "Kode Anggota", "Nama", "NIM", "Jurusan", "Kontak"});
        model.setRowCount(0);

        ArrayList<Mahasiswa> list = new MahasiswaController().getAll();
        for (Mahasiswa m : list) {
            model.addRow(new Object[]{
                m.getIdAnggota(),
                m.getKodeAnggota(),
                m.getNama(),
                m.getNim(),
                m.getJurusan(),
                m.getKontak()
            });
        }
    }

    // Menampilkan data Pegawai
    private void tampilkanPegawai() {
        model.setColumnIdentifiers(new Object[]{"ID", "NIP", "Nama", "Jabatan", "Email", "Telepon"});
        model.setRowCount(0);
        ArrayList<Pegawai> list = new PegawaiController().getAll();
        for (Pegawai p : list) {
            model.addRow(new Object[]{
                p.getId(), p.getNip(), p.getNama(), p.getJabatan(),
                p.getEmail(), p.getTelepon() // Menambahkan NIP ke dalam tabel
            });
        }
    }

    private void tampilkanPeminjaman() {
        model.setColumnIdentifiers(new Object[]{
            "ID Peminjaman", "Kode Anggota", "Nama Anggota", "Kode Buku", "NIP Pegawai", "Tanggal Pinjam", "Tanggal Kembali", "Jumlah Pinjam"
        });
        model.setRowCount(0);
        ArrayList<Peminjaman> list = new PeminjamanController().getAll();
        for (Peminjaman p : list) {
            model.addRow(new Object[]{
                p.getIdPeminjaman(),
                p.getKodeAnggota(),
                p.getNamaAnggota(),
                p.getKodeBuku(),
                p.getNip(),
                p.getTanggalPinjam(),
                p.getTanggalKembali(),
                p.getTotalPinjam()
            });
        }
    }

    private void tampilkanArsip() {
        model.setColumnIdentifiers(new Object[]{
            "ID Arsip", "Kode Anggota", "Kode Buku", "NIP Pegawai", "Tanggal Pinjam",
            "Tanggal Kembali", "Tanggal Pengembalian", "Total Pinjam", "Kondisi Buku", "Total Denda"
        });

        ArrayList<ArsipPeminjaman> listArsip = new ArsipPeminjamanController().getAllArsip();
        model.setRowCount(0);

        for (ArsipPeminjaman arsip : listArsip) {
            model.addRow(new Object[]{
                arsip.getIdArsip(),
                arsip.getKodeAnggota(),
                arsip.getKodeBuku(),
                arsip.getNipPegawai(),
                arsip.getTanggalPinjam(),
                arsip.getTanggalKembali(),
                arsip.getTanggalPengembalian(),
                arsip.getTotalPinjam(),
                arsip.getKondisiBuku(),
                arsip.getTotalDenda()
            });
        }
    }

    // Menampilkan data laporan pada tombol
    private void tampilkanLaporan() {
        LaporanController controller = new LaporanController();
        Laporan laporan = controller.getLaporan();

        if (laporan != null) {
            updateButtonText(btnJumlahBuku, "Jumlah Buku", String.valueOf(laporan.getJumlahBuku()));
            updateButtonText(btnJumlahMahasiswa, "Jumlah Anggota", String.valueOf(laporan.getJumlahMahasiswa()));
            updateButtonText(btnJumlahPegawai, "Jumlah Pegawai", String.valueOf(laporan.getJumlahPegawai()));
            updateButtonText(btnTotalPeminjaman, "Total Peminjaman", String.valueOf(laporan.getTotalPeminjaman()));
            updateButtonText(btnJumlahArsipPengembalian, "Jumlah Arsip Pengembalian", String.valueOf(laporan.getJumlahArsipPengembalian()));
            updateButtonText(btnTotalDenda, "Total Denda", String.valueOf(laporan.getTotalDenda()));

            // Update tabel
            model.setRowCount(0); // hapus baris lama
            model.addRow(new Object[]{
                laporan.getJumlahBuku(),
                laporan.getJumlahMahasiswa(),
                laporan.getJumlahPegawai(),
                laporan.getTotalPeminjaman(),
                laporan.getJumlahArsipPengembalian(),
                laporan.getTotalDenda()
            });
        } else {
            JOptionPane.showMessageDialog(this, "Gagal memuat data laporan.");
        }
    }

    public void tampilkanTotalDenda() {
        try {
            java.util.Date tanggalAwalUtil = (java.util.Date) spinnerTanggalAwal.getValue();
            java.util.Date tanggalAkhirUtil = (java.util.Date) spinnerTanggalAkhir.getValue();

            if (tanggalAwalUtil.after(tanggalAkhirUtil)) {
                JOptionPane.showMessageDialog(this, "Tanggal awal tidak boleh lebih besar dari tanggal akhir.");
                return;
            }

            java.sql.Date tanggalAwal = new java.sql.Date(tanggalAwalUtil.getTime());
            java.sql.Date tanggalAkhir = new java.sql.Date(tanggalAkhirUtil.getTime());

            // Ambil data arsipnya
            ArrayList<ArsipPeminjaman> list = new ArsipPeminjamanController().getAllArsip(tanggalAwal, tanggalAkhir);

            // Ambil total dendanya
            int totalDenda = new ArsipPeminjamanController().getTotalDenda(tanggalAwal, tanggalAkhir);

            // Set kolom tabel sesuai data arsip lengkap
            model.setColumnIdentifiers(new Object[]{
                "ID Arsip", "Kode Anggota", "Kode Buku", "NIP Pegawai", "Tanggal Pengembalian", "Total Denda"
            });
            model.setRowCount(0);

            // Tambahkan semua arsip ke tabel
            for (ArsipPeminjaman a : list) {
                model.addRow(new Object[]{
                    a.getIdArsip(),
                    a.getKodeAnggota(),
                    a.getKodeBuku(),
                    a.getNipPegawai(),
                    a.getTanggalPengembalian(),
                    a.getTotalDenda()
                });
            }

            // Tampilkan total denda di dialog atau label terpisah
            JOptionPane.showMessageDialog(this, "Total denda dari tanggal " + tanggalAwal + " sampai " + tanggalAkhir + " adalah Rp " + totalDenda);

            // Jika kamu punya JLabel khusus untuk total denda, bisa update juga di sini, misal:
            // labelTotalDenda.setText("Total Denda: Rp " + totalDenda);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error saat menampilkan total denda dan arsip: " + ex.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LaporanView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LaporanView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LaporanView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LaporanView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

    
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
