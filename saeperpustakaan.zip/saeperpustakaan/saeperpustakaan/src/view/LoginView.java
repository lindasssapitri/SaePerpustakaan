package view;

import controller.LoginController;
import model.Login;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.HomeView;

public class LoginView extends JFrame {

    private JTextField tfUsername;
    private JPasswordField pfPassword;
    private JButton btnLogin;
    private LoginController loginController;

    public LoginView() {
        loginController = new LoginController();

        setTitle("Login - Sistem Pendaftaran Mahasiswa");
        setSize(800, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Tengah layar
        setUndecorated(true); // Hilangkan frame default
        getRootPane().setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
        // Tombol Close (X) - diperkecil dan lebih presisi
        JButton btnClose = new JButton("X");
        btnClose.setMargin(new Insets(0, 0, 0, 0)); // hilangkan padding
        btnClose.setPreferredSize(new Dimension(30, 30)); // ukuran kecil
        btnClose.setFocusPainted(false);
        btnClose.setBorderPainted(false);
        btnClose.setContentAreaFilled(false);
        btnClose.setForeground(Color.GRAY);
        btnClose.setFont(new Font("SansSerif", Font.BOLD, 14)); // diperkecil
        btnClose.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnClose.setToolTipText("Tutup Aplikasi");
        btnClose.addActionListener(e -> System.exit(0));

// Panel untuk tombol close
        JPanel closePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        closePanel.setOpaque(false);
        closePanel.setPreferredSize(new Dimension(800, 30)); // tinggi kecil
        closePanel.add(btnClose);

        // Panel utama
        JPanel mainPanel = new JPanel(new GridLayout(1, 2));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.setBackground(Color.WHITE);

        // PANEL KIRI
        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(new Color(0, 102, 204)); // Hijau tua
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBorder(BorderFactory.createEmptyBorder(40, 20, 40, 20));

        // Ikon Perpustakaan (gunakan Unicode buku atau ikon dari UIManager)
        JLabel lblIcon = new JLabel("📚");
        lblIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 100)); // jika tersedia
        lblIcon.setForeground(Color.WHITE);
        lblIcon.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Judul Aplikasi
        JLabel lblApp = new JLabel("SAE PERPUSTAKAAN");
        lblApp.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblApp.setForeground(Color.WHITE);
        lblApp.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblApp.setHorizontalAlignment(SwingConstants.CENTER);

        // Garis pemisah
        JSeparator separator = new JSeparator(SwingConstants.HORIZONTAL);
        separator.setMaximumSize(new Dimension(Integer.MAX_VALUE, 2));
        separator.setForeground(Color.WHITE);

        // Deskripsi
        JLabel lblDesc = new JLabel("<html><div style='text-align: center;'>"
                + "Selamat Datang di<br>"
                + "<b>Sistem Administrasi Perpustakaan Digital</b><br>"
                + "STMIK Widya Utama Purwokerto<br>"
                + "<i>Tahun Akademik 2025/2026</i></div></html>");
        lblDesc.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblDesc.setForeground(Color.WHITE);
        lblDesc.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblDesc.setHorizontalAlignment(SwingConstants.CENTER);

        // Tambahkan komponen ke panel
        leftPanel.add(lblIcon);
        leftPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        leftPanel.add(lblApp);
        leftPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        leftPanel.add(separator);
        leftPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        leftPanel.add(lblDesc);

        /**
         * PANEL KANAN *
         */
        JPanel rightPanel = new JPanel(new GridBagLayout());
        rightPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 20, 8, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblLogin = new JLabel("Login User");
        lblLogin.setFont(new Font("SansSerif", Font.BOLD, 22));
        lblLogin.setHorizontalAlignment(SwingConstants.CENTER);

        // Ikon media sosial
        JPanel socialPanel = new JPanel();
        socialPanel.setOpaque(false);
        socialPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 5));
        String[] icons = {"📚", "S", "A", "E"}; // simbol ikon
        for (String icon : icons) {
            JLabel iconLabel = new JLabel(icon, SwingConstants.CENTER);
            iconLabel.setPreferredSize(new Dimension(35, 35));
            iconLabel.setOpaque(true);
            iconLabel.setBackground(Color.WHITE);
            iconLabel.setBorder(BorderFactory.createLineBorder(new Color(180, 180, 180)));
            iconLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
            socialPanel.add(iconLabel);
        }

        JLabel lblOr = new JLabel("Gunakan akunmu:");
        lblOr.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblOr.setHorizontalAlignment(SwingConstants.CENTER);

        tfUsername = new JTextField();
        tfUsername.setPreferredSize(new Dimension(200, 30));

        pfPassword = new JPasswordField();
        pfPassword.setPreferredSize(new Dimension(200, 30));

        btnLogin = new JButton("LOGIN");
        btnLogin.setBackground(new Color(0, 102, 204));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnLogin.setFocusPainted(false);
        btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JLabel lblForgot = new JLabel("");
        lblForgot.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblForgot.setForeground(Color.GRAY);
        lblForgot.setHorizontalAlignment(SwingConstants.CENTER);

        // Tambahkan elemen ke panel kanan
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        rightPanel.add(lblLogin, gbc);

        gbc.gridy++;
        rightPanel.add(socialPanel, gbc);

        gbc.gridy++;
        rightPanel.add(lblOr, gbc);

        gbc.gridy++;
        rightPanel.add(tfUsername, gbc);

        gbc.gridy++;
        rightPanel.add(pfPassword, gbc);

        gbc.gridy++;
        rightPanel.add(btnLogin, gbc);

        gbc.gridy++;
        rightPanel.add(lblForgot, gbc);

        // Tambahkan ke panel utama
        mainPanel.add(rightPanel);
        mainPanel.add(leftPanel);

        add(mainPanel);

        btnLogin.addActionListener(e -> {
            String username = tfUsername.getText().trim();
            String password = new String(pfPassword.getPassword()).trim();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(LoginView.this,
                        "Username dan password tidak boleh kosong!",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            Login user = loginController.loginUser(username, password);
            if (user != null) {
                HomeView homeView = new HomeView(user, LoginView.this);
                homeView.setVisible(true);
                setVisible(false);  // LoginView tidak di dispose, nanti bisa dipakai saat logout

                // Kosongkan inputan setelah login sukses
                tfUsername.setText("");
                pfPassword.setText("");
            } else {
                JOptionPane.showMessageDialog(LoginView.this,
                        "Login gagal! Username atau password salah.",
                        "Gagal",
                        JOptionPane.ERROR_MESSAGE);
            }
        });
        setLayout(new BorderLayout());
        add(closePanel, BorderLayout.NORTH);  // tombol close di atas
        add(mainPanel, BorderLayout.CENTER);  // isi utama di tengah

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
