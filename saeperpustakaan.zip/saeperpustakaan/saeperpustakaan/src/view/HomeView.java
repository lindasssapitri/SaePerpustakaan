package view;

import view.MainView;
import view.TransaksiView;
import model.Login;

import javax.swing.*;
import java.awt.*;

public class HomeView extends JFrame {

    private Login user; // field untuk simpan user login
    private final JFrame loginView;

    public HomeView(Login user, JFrame loginView) {
        this.user = user; // simpan user
        this.loginView = loginView;

        // Frame utama pakai BorderLayout
        setLayout(new BorderLayout());
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        // Panel atas: berisi kiri (judul + keterangan + welcome) dan kanan (logout)
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // padding

        // Panel judul aplikasi (3 label vertikal)
        JPanel titlePanel = new JPanel();
        titlePanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.setOpaque(false);

        JLabel lblAppTitle = new JLabel("SAE PERPUSTAKAAN");
        lblAppTitle.setFont(new Font("Arial", Font.BOLD, 50));  // Ukuran diperbesar
        lblAppTitle.setForeground(new Color(0, 102, 204));       // Warna biru tua
        lblAppTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblSubtitle = new JLabel("Sistem Administrasi Perpustakaan Digital");
        lblSubtitle.setFont(new Font("Arial", Font.ITALIC, 25));  // Italic & sedikit lebih besar
        lblSubtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblInstitution = new JLabel("STMIK WIDYA UTAMA PURWOKERTO");
        lblInstitution.setFont(new Font("Arial", Font.PLAIN, 20));
        lblInstitution.setAlignmentX(Component.LEFT_ALIGNMENT);

        titlePanel.add(lblAppTitle);
        titlePanel.add(Box.createVerticalStrut(8)); // jarak antar label
        titlePanel.add(lblSubtitle);
        titlePanel.add(Box.createVerticalStrut(8)); // jarak antar label
        titlePanel.add(lblInstitution);

        // Label selamat datang di bawah judul
        JLabel lblWelcome = new JLabel("<html>Selamat datang, " + user.getUsername() + "!<br>(Role: " + user.getRole() + ")</html>");
        lblWelcome.setFont(new Font("Arial", Font.BOLD, 14)); // Diperkecil dari 24 ke 18
        lblWelcome.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Panel kiri gabungan judul + welcome
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setOpaque(false);
        leftPanel.add(titlePanel);
        leftPanel.add(Box.createVerticalStrut(50)); // spasi
        leftPanel.add(lblWelcome);
        leftPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

// Tambahkan ke topPanel bagian kiri
        topPanel.add(leftPanel, BorderLayout.WEST);

// Tombol Logout di kanan
        JButton btnLogout = new JButton("🔙Logout");
        btnLogout.setPreferredSize(new Dimension(100, 30));
        btnLogout.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                    HomeView.this,
                    "Apakah Anda yakin ingin logout?",
                    "Konfirmasi Logout",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                loginView.setVisible(true);
                dispose();
            }
        });

        // Panel kanan agar tombol logout tetap di pojok atas dan tidak terdorong ke tengah
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        rightPanel.setOpaque(false);
        rightPanel.add(btnLogout);

        // Tambahkan ke topPanel kanan
        topPanel.add(rightPanel, BorderLayout.EAST);

        // Tambahkan panel atas ke frame utama
        add(topPanel, BorderLayout.NORTH);
        // Panel kanan agar tombol logout tetap di pojok atas dan tidak terdorong ke tengah

        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setOpaque(false);

        // Tambahkan tombol Logout
        btnLogout.setAlignmentX(Component.RIGHT_ALIGNMENT);
        rightPanel.add(btnLogout);

        // Tambahkan jarak kecil
        rightPanel.add(Box.createVerticalStrut(10));

        // Tambahkan gambar di bawah tombol logout
        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/img/logo1.png")); // sesuaikan path
            Image scaledImage = icon.getImage().getScaledInstance(500, 500, Image.SCALE_SMOOTH);
            JLabel lblImage = new JLabel(new ImageIcon(scaledImage));
            lblImage.setAlignmentX(Component.RIGHT_ALIGNMENT);
            rightPanel.add(lblImage);
        } catch (Exception ex) {
            System.out.println("Gagal memuat gambar: " + ex.getMessage());
        }

        // Panel utama kosong di tengah
        JPanel mainPanel = new JPanel(new BorderLayout());
        add(mainPanel, BorderLayout.CENTER);

        // Panel footer dengan tombol Master, Transaksi, Laporan
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 40));
        footerPanel.setBackground(new Color(0, 102, 204));

        JButton btnMaster = new JButton(
                "<html><div style='text-align:center; width:120px;'>"
                + "<span style='font-size:48px;'>📚</span><br>"
                + "<span style='font-size:18px;'>MASTER</span>"
                + "</div></html>");

        JButton btnTransaksi = new JButton(
                "<html><div style='text-align:center; width:120px;'>"
                + "<span style='font-size:48px;'>📅</span><br>"
                + "<span style='font-size:18px;'>TRANSAKSI</span>"
                + "</div></html>");

        JButton btnLaporan = new JButton(
                "<html><div style='text-align:center; width:120px;'>"
                + "<span style='font-size:48px;'>📂</span><br>"
                + "<span style='font-size:18px;'>LAPORAN</span>"
                + "</div></html>");

        Dimension size = new Dimension(200, 125);

        btnMaster.setPreferredSize(size);
        btnTransaksi.setPreferredSize(size);
        btnLaporan.setPreferredSize(size);

        footerPanel.add(btnMaster);
        footerPanel.add(btnTransaksi);
        footerPanel.add(btnLaporan);

        add(footerPanel, BorderLayout.SOUTH);

        // Set button enable/disable sesuai role
        if (user.getRole().equalsIgnoreCase("admin")) {
            btnMaster.setEnabled(true);
            btnTransaksi.setEnabled(true);
            btnLaporan.setEnabled(true);
        } else if (user.getRole().equalsIgnoreCase("petugas")) {
            btnMaster.setEnabled(true);
            btnTransaksi.setEnabled(true);
            btnLaporan.setEnabled(false);
        } else {
            btnMaster.setEnabled(false);
            btnTransaksi.setEnabled(false);
            btnLaporan.setEnabled(false);
        }

        btnMaster.addActionListener(e -> {
            new MainView(user, HomeView.this).setVisible(true);
            setVisible(false);
        });

        btnTransaksi.addActionListener(e -> {
            new TransaksiView(user, HomeView.this).setVisible(true);
            setVisible(false);
        });

        btnLaporan.addActionListener(e -> {
            new LaporanView(user, HomeView.this).setVisible(true);
            setVisible(false);
        });
    }

    // </editor-fold>
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomeView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
