package view;

import controller.BukuController;
import controller.MahasiswaController;
import controller.PegawaiController;
import controller.PeminjamanController;
import controller.ArsipPeminjamanController;
import controller.UserController;
import controller.RakController;
import model.Buku;
import model.Mahasiswa;
import model.Pegawai;
import model.Peminjaman;
import model.ArsipPeminjaman;
import model.User;
import model.Rak;
import model.Login;
import java.util.Calendar;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.sql.Date;
import javax.swing.Timer;
import java.util.concurrent.TimeUnit;

public class TransaksiView extends JFrame {
    private Login user;

    private final JButton btnPeminjaman;
    private final JButton btnArsip;
    private final JButton btnKembali;
    private final JTable table;
    private final DefaultTableModel model;
    private final JPanel panelAtas;
    private final JPanel panelKiri;

    private String currentView = "";
    private JFrame homeView;  // ini field class


    public TransaksiView(Login user, JFrame homeView) {
        this.user = user;
        this.homeView = homeView;
        
        setTitle("Data Perpustakaan");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel Header
        JPanel panelHeader = new JPanel();
        panelHeader.setLayout(new BoxLayout(panelHeader, BoxLayout.Y_AXIS));
        panelHeader.setBackground(new Color(0, 102, 204));
        panelHeader.setBorder(BorderFactory.createEmptyBorder(60, 0, 60, 0));

        JLabel labelHeader = new JLabel("TRANSAKSI SAE PERPUSTAKAAN");
        labelHeader.setFont(new Font("Arial", Font.BOLD, 34));
        labelHeader.setForeground(Color.WHITE);
        labelHeader.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel labelSubjudul = new JLabel("Sistem Administrasi Perpustakaan Digital");
        labelSubjudul.setFont(new Font("Arial", Font.PLAIN, 16));
        labelSubjudul.setForeground(new Color(230, 230, 230));
        labelSubjudul.setAlignmentX(Component.CENTER_ALIGNMENT);

        panelHeader.add(labelHeader);
        panelHeader.add(Box.createVerticalStrut(10));
        panelHeader.add(labelSubjudul);

        // Panel Navigasi Atas
        panelAtas = new JPanel();
        panelAtas.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));
        panelAtas.setBackground(new Color(240, 240, 240));
        panelAtas.setBorder(BorderFactory.createEmptyBorder(0, 100, 0, 0));

        btnPeminjaman = new JButton("📅 Peminjaman");
        btnArsip = new JButton("📂 Arsip Peminjaman");

        Dimension buttonSize = new Dimension(150, 40);
        JButton[] buttons = {btnPeminjaman, btnArsip};
        for (JButton btn : buttons) {
            btn.setPreferredSize(buttonSize);
            panelAtas.add(btn);
        }

        JPanel panelUtamaAtas = new JPanel();
        panelUtamaAtas.setLayout(new BoxLayout(panelUtamaAtas, BoxLayout.Y_AXIS));
        panelUtamaAtas.add(panelHeader);
        panelUtamaAtas.add(panelAtas);
        add(panelUtamaAtas, BorderLayout.NORTH);

        // Tabel
        model = new DefaultTableModel();
        table = new JTable(model);
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(200, 200, 200));
        add(new JScrollPane(table), BorderLayout.CENTER);

        // Panel kiri untuk tombol CRUD + tombol kembali
        panelKiri = new JPanel();
        panelKiri.setLayout(new BoxLayout(panelKiri, BoxLayout.Y_AXIS));
        panelKiri.setBackground(new Color(245, 245, 245));

        JButton btnTambah = new JButton("➕ Tambah");
        JButton btnEdit = new JButton("✏️ Edit");
        JButton btnHapus = new JButton("🗑️ Hapus");
        JButton btnProses = new JButton("🔄 Proses");
        btnKembali = new JButton("🔙 Kembali");

        btnTambah.setMaximumSize(buttonSize);
        btnEdit.setMaximumSize(buttonSize);
        btnHapus.setMaximumSize(buttonSize);
        btnProses.setMaximumSize(buttonSize);
        btnKembali.setMaximumSize(buttonSize);

        btnTambah.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnEdit.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnHapus.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnProses.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnKembali.setAlignmentX(Component.CENTER_ALIGNMENT);

        panelKiri.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 20));
        panelKiri.add(Box.createVerticalStrut(10));
        panelKiri.add(btnTambah);
        panelKiri.add(Box.createVerticalStrut(10));
        panelKiri.add(btnEdit);
        panelKiri.add(Box.createVerticalStrut(10));
        panelKiri.add(btnHapus);
        panelKiri.add(Box.createVerticalStrut(10));
        panelKiri.add(btnProses);
        panelKiri.add(Box.createVerticalStrut(20));
        panelKiri.add(btnKembali);
        panelKiri.add(Box.createVerticalStrut(10));

        add(panelKiri, BorderLayout.WEST);

        // Aksi tombol kembali
        btnKembali.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Apakah Anda yakin ingin kembali ke halaman utama?",
                    "Konfirmasi Kembali",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                homeView.setVisible(true);  // cukup munculkan kembali HomeView lama
                this.dispose();  // tutup TransaksiView ini
            }
        });

        btnPeminjaman.addActionListener(e -> {
            currentView = "peminjaman";
            tampilkanPeminjaman();
        });

        btnArsip.addActionListener(e -> {
            currentView = "arsip";
            tampilkanArsip();
        });

        currentView = "peminjaman";
        tampilkanPeminjaman();

        btnTambah.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentView.equals("peminjaman")) {
                    // Ambil data combo box
                    ArrayList<String> anggotaList = new PeminjamanController().getKodeAnggotaWithNama();
                    ArrayList<String> bukuList = new PeminjamanController().getKodeBukuWithJudulAndStok();
                    ArrayList<String> pegawaiList = new PeminjamanController().getNipPegawaiWithNama();

                    JComboBox<String> cbKodeAnggota = new JComboBox<>();
                    for (String item : anggotaList) {
                        cbKodeAnggota.addItem(item);
                    }
                    cbKodeAnggota.setEditable(true);

                    JComboBox<String> cbKodeBuku = new JComboBox<>();
                    for (String item : bukuList) {
                        cbKodeBuku.addItem(item);
                    }
                    cbKodeBuku.setEditable(true);

                    JComboBox<String> cbNipPegawai = new JComboBox<>();
                    for (String item : pegawaiList) {
                        cbNipPegawai.addItem(item);
                    }
                    cbNipPegawai.setEditable(true);

                    JSpinner spinnerTanggalPinjam = new JSpinner(new SpinnerDateModel());
                    JSpinner spinnerTanggalKembali = new JSpinner(new SpinnerDateModel());
                    spinnerTanggalPinjam.setEditor(new JSpinner.DateEditor(spinnerTanggalPinjam, "yyyy-MM-dd"));
                    spinnerTanggalKembali.setEditor(new JSpinner.DateEditor(spinnerTanggalKembali, "yyyy-MM-dd"));

                    JSpinner spinnerTotalPinjam = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));

                    Object[] inputFields = {
                        "Kode Anggota Mahasiswa:", cbKodeAnggota,
                        "Kode Buku:", cbKodeBuku,
                        "NIP Pegawai:", cbNipPegawai,
                        "Tanggal Pinjam:", spinnerTanggalPinjam,
                        "Tanggal Kembali:", spinnerTanggalKembali,
                        "Jumlah Pinjam:", spinnerTotalPinjam
                    };

                    int option = JOptionPane.showConfirmDialog(TransaksiView.this, inputFields, "Tambah Peminjaman", JOptionPane.OK_CANCEL_OPTION);

                    if (option == JOptionPane.OK_OPTION) {
                        try {
                            String selectedAnggota = (String) cbKodeAnggota.getSelectedItem();
                            String kodeAnggota = selectedAnggota != null && selectedAnggota.contains(" - ") ? selectedAnggota.substring(0, selectedAnggota.indexOf(" - ")) : selectedAnggota;

                            String selectedBuku = (String) cbKodeBuku.getSelectedItem();
                            String kodeBuku = selectedBuku != null && selectedBuku.contains(" - ") ? selectedBuku.substring(0, selectedBuku.indexOf(" - ")) : selectedBuku;

                            String selectedNip = (String) cbNipPegawai.getSelectedItem();
                            String nip = selectedNip != null && selectedNip.contains(" - ") ? selectedNip.substring(0, selectedNip.indexOf(" - ")) : selectedNip;

                            java.util.Date tanggalPinjam = (java.util.Date) spinnerTanggalPinjam.getValue();
                            java.util.Date tanggalKembali = (java.util.Date) spinnerTanggalKembali.getValue();
                            Date sqlTanggalPinjam = new Date(tanggalPinjam.getTime());
                            Date sqlTanggalKembali = new Date(tanggalKembali.getTime());

                            int totalPinjam = (Integer) spinnerTotalPinjam.getValue();
                            System.out.println("DEBUG: totalPinjam dari spinner = " + totalPinjam);

                            Peminjaman p = new Peminjaman(
                                    0, kodeBuku, kodeAnggota, "", nip, sqlTanggalPinjam, sqlTanggalKembali, totalPinjam
                            );

                            new PeminjamanController().tambahPeminjaman(p);

                            tampilkanPeminjaman();
                            JOptionPane.showMessageDialog(TransaksiView.this, "Peminjaman berhasil ditambahkan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);

                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(TransaksiView.this, "Terjadi kesalahan: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
        });

        btnEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(TransaksiView.this, "Pilih data dulu!");
                    return;
                }

                if (currentView.equals("arsip")) {
                    // === BAGIAN EDIT ARSIP ===
                    int idArsip = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());

                    String[] options = {"Lihat Detail Arsip", "Batalkan Arsip", "Batal"};
                    int choice = JOptionPane.showOptionDialog(
                            TransaksiView.this,
                            "Pilih aksi untuk arsip yang dipilih:",
                            "Edit Arsip Peminjaman",
                            JOptionPane.DEFAULT_OPTION,
                            JOptionPane.INFORMATION_MESSAGE,
                            null,
                            options,
                            options[0]
                    );

                    ArsipPeminjamanController arsipController = new ArsipPeminjamanController();

                    if (choice == 0) {
                        // Lihat detail arsip
                        ArsipPeminjaman arsip = arsipController.getAllArsip().stream()
                                .filter(a -> a.getIdArsip() == idArsip)
                                .findFirst()
                                .orElse(null);

                        if (arsip != null) {
                            StringBuilder detail = new StringBuilder();
                            detail.append("ID Arsip             : ").append(arsip.getIdArsip()).append("\n");
                            detail.append("Kode Anggota         : ").append(arsip.getKodeAnggota()).append("\n");
                            detail.append("Kode Buku            : ").append(arsip.getKodeBuku()).append("\n");
                            detail.append("NIP Pegawai          : ").append(arsip.getNipPegawai()).append("\n");
                            detail.append("Tanggal Pinjam       : ").append(arsip.getTanggalPinjam()).append("\n");
                            detail.append("Tanggal Kembali      : ").append(arsip.getTanggalKembali()).append("\n");
                            detail.append("Tanggal Pengembalian : ").append(arsip.getTanggalPengembalian()).append("\n");
                            detail.append("Total Pinjam         : ").append(arsip.getTotalPinjam()).append("\n");
                            detail.append("Kondisi Buku         : ").append(arsip.getKondisiBuku()).append("\n");
                            detail.append("Total Denda          : ").append(arsip.getTotalDenda()).append("\n");

                            JTextArea textArea = new JTextArea(detail.toString());
                            textArea.setEditable(false);
                            textArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
                            textArea.setLineWrap(true);
                            textArea.setWrapStyleWord(true);
                            textArea.setMargin(new Insets(10, 10, 10, 10));

                            JScrollPane scrollPane = new JScrollPane(textArea);
                            scrollPane.setPreferredSize(new Dimension(400, 300));

                            JOptionPane.showMessageDialog(TransaksiView.this, scrollPane, "Detail Arsip", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(TransaksiView.this, "Data arsip tidak ditemukan.", "Error", JOptionPane.ERROR_MESSAGE);
                        }

                    } else if (choice == 1) {
                        int konfirmasi = JOptionPane.showConfirmDialog(TransaksiView.this,
                                "Apakah Anda yakin ingin membatalkan arsip ini?",
                                "Konfirmasi Batalkan Arsip",
                                JOptionPane.YES_NO_OPTION);

                        if (konfirmasi == JOptionPane.YES_OPTION) {
                            boolean berhasil = arsipController.batalkanPengarsipan(idArsip);
                            if (berhasil) {
                                JOptionPane.showMessageDialog(TransaksiView.this, "Arsip berhasil dibatalkan.", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                                tampilkanArsip();
                            } else {
                                JOptionPane.showMessageDialog(TransaksiView.this, "Gagal membatalkan arsip.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }

                } else {
                    // === BAGIAN EDIT PEMINJAMAN ===
                    String action = "peminjaman";
                    if ("peminjaman".equals(action)) {
                        int idPinjam = (int) table.getValueAt(selectedRow, 0);
                        String kodeAnggotaPinjam = (String) table.getValueAt(selectedRow, 1);
                        String kodeBuku = (String) table.getValueAt(selectedRow, 3);
                        String nipPinjam = (String) table.getValueAt(selectedRow, 4);
                        Date tanggalPinjam = (Date) table.getValueAt(selectedRow, 5);
                        Date tanggalKembali = (Date) table.getValueAt(selectedRow, 6);
                        int totalPinjam = (int) table.getValueAt(selectedRow, 7);

                        ArrayList<String> anggotaList = new PeminjamanController().getKodeAnggotaWithNama();
                        ArrayList<String> bukuList = new PeminjamanController().getKodeBukuWithJudulAndStok();
                        ArrayList<String> pegawaiList = new PeminjamanController().getNipPegawaiWithNama();

                        JComboBox<String> cbKodeAnggota = new JComboBox<>();
                        for (String item : anggotaList) {
                            cbKodeAnggota.addItem(item);
                            if (item.startsWith(kodeAnggotaPinjam + " -")) {
                                cbKodeAnggota.setSelectedItem(item);
                            }
                        }

                        JComboBox<String> cbKodeBuku = new JComboBox<>();
                        for (String item : bukuList) {
                            cbKodeBuku.addItem(item);
                            if (item.startsWith(kodeBuku + " -")) {
                                cbKodeBuku.setSelectedItem(item);
                            }
                        }

                        JComboBox<String> cbNipPegawai = new JComboBox<>();
                        for (String item : pegawaiList) {
                            cbNipPegawai.addItem(item);
                            if (item.startsWith(nipPinjam + " -")) {
                                cbNipPegawai.setSelectedItem(item);
                            }
                        }

                        JSpinner spinnerTanggalPinjam = new JSpinner(new SpinnerDateModel(tanggalPinjam, null, null, Calendar.DAY_OF_MONTH));
                        spinnerTanggalPinjam.setEditor(new JSpinner.DateEditor(spinnerTanggalPinjam, "yyyy-MM-dd"));
                        JSpinner spinnerTanggalKembali = new JSpinner(new SpinnerDateModel(tanggalKembali, null, null, Calendar.DAY_OF_MONTH));
                        spinnerTanggalKembali.setEditor(new JSpinner.DateEditor(spinnerTanggalKembali, "yyyy-MM-dd"));

                        JSpinner spinnerTotalPinjam = new JSpinner(new SpinnerNumberModel(totalPinjam, 1, 100, 1));

                        Object[] inputPinjam = {
                            "Kode Anggota Mahasiswa:", cbKodeAnggota,
                            "Kode Buku:", cbKodeBuku,
                            "NIP Pegawai:", cbNipPegawai,
                            "Tanggal Pinjam:", spinnerTanggalPinjam,
                            "Tanggal Kembali:", spinnerTanggalKembali,
                            "Total Pinjam:", spinnerTotalPinjam
                        };

                        int optionPinjam = JOptionPane.showConfirmDialog(TransaksiView.this, inputPinjam, "Edit Peminjaman", JOptionPane.OK_CANCEL_OPTION);
                        if (optionPinjam == JOptionPane.OK_OPTION) {
                            try {
                                String kodeAnggota = cbKodeAnggota.getSelectedItem().toString().split(" - ")[0];
                                String kodeBukuNew = cbKodeBuku.getSelectedItem().toString().split(" - ")[0];
                                String nip = cbNipPegawai.getSelectedItem().toString().split(" - ")[0];

                                java.util.Date tanggalPinjamUtil = (java.util.Date) spinnerTanggalPinjam.getValue();
                                java.util.Date tanggalKembaliUtil = (java.util.Date) spinnerTanggalKembali.getValue();
                                int totalPinjamBaru = (int) spinnerTotalPinjam.getValue();

                                Date sqlTanggalPinjam = new Date(tanggalPinjamUtil.getTime());
                                Date sqlTanggalKembali = new Date(tanggalKembaliUtil.getTime());

                                Peminjaman p = new Peminjaman(
                                        idPinjam,
                                        kodeBukuNew,
                                        kodeAnggota,
                                        "",
                                        nip,
                                        sqlTanggalPinjam,
                                        sqlTanggalKembali,
                                        totalPinjamBaru
                                );

                                new PeminjamanController().updatePeminjaman(p);
                                tampilkanPeminjaman();

                            } catch (IllegalArgumentException ex) {
                                JOptionPane.showMessageDialog(TransaksiView.this, "Format tanggal tidak valid. Gunakan format yyyy-MM-dd.");
                            }
                        }
                    }
                }
            }
        });

        btnHapus.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int confirm = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    int id = (int) table.getValueAt(selectedRow, 0);
                    switch (currentView) {
                        case "peminjaman":
                            new PeminjamanController().deletePeminjaman(id);
                            tampilkanPeminjaman();
                            break;
                        case "arsip":
                            new ArsipPeminjamanController().deleteArsipPeminjaman(id);
                            tampilkanArsip();
                            break;
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Pilih baris terlebih dahulu yang ingin dihapus.");
            }
        });

        btnProses.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(TransaksiView.this, "Pilih data dulu!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Ambil data dari baris yang dipilih
                int idPinjam = (int) table.getValueAt(selectedRow, 0);
                String kodeAnggotaPinjam = (String) table.getValueAt(selectedRow, 1);
                String namaAnggota = (String) table.getValueAt(selectedRow, 2);
                String kodeBuku = (String) table.getValueAt(selectedRow, 3);
                String nipPinjam = (String) table.getValueAt(selectedRow, 4);
                Date tanggalPinjam = (Date) table.getValueAt(selectedRow, 5);
                Date tanggalKembali = (Date) table.getValueAt(selectedRow, 6);
                int totalPinjam = (int) table.getValueAt(selectedRow, 7);

                // Fungsi untuk tampilkan dialog input pengembalian, return null kalau batal
                class PengembalianData {

                    Date tanggalPengembalian;
                    String kondisiBuku;
                }

                PengembalianData pengembalian = new PengembalianData();

                while (true) {
                    JPanel panel = new JPanel(new GridBagLayout());
                    GridBagConstraints gbc = new GridBagConstraints();
                    gbc.insets = new Insets(5, 5, 5, 5);
                    gbc.anchor = GridBagConstraints.WEST;

                    gbc.gridx = 0;
                    gbc.gridy = 0;
                    panel.add(new JLabel("ID Peminjaman:"), gbc);
                    gbc.gridx = 1;
                    panel.add(new JLabel(String.valueOf(idPinjam)), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    panel.add(new JLabel("Kode Anggota:"), gbc);
                    gbc.gridx = 1;
                    panel.add(new JLabel(kodeAnggotaPinjam + " - " + namaAnggota), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    panel.add(new JLabel("Kode Buku:"), gbc);
                    gbc.gridx = 1;
                    panel.add(new JLabel(kodeBuku), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    panel.add(new JLabel("NIP Pegawai:"), gbc);
                    gbc.gridx = 1;
                    panel.add(new JLabel(nipPinjam), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    panel.add(new JLabel("Tanggal Pinjam:"), gbc);
                    gbc.gridx = 1;
                    panel.add(new JLabel(tanggalPinjam.toString()), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    panel.add(new JLabel("Tanggal Kembali (Jatuh Tempo):"), gbc);
                    gbc.gridx = 1;
                    panel.add(new JLabel(tanggalKembali.toString()), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    panel.add(new JLabel("Jumlah Pinjam:"), gbc);
                    gbc.gridx = 1;
                    panel.add(new JLabel(String.valueOf(totalPinjam)), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    panel.add(new JLabel("Tanggal Pengembalian:"), gbc);
                    gbc.gridx = 1;
                    JSpinner spinnerTanggalPengembalian = new JSpinner(new SpinnerDateModel());
                    spinnerTanggalPengembalian.setEditor(new JSpinner.DateEditor(spinnerTanggalPengembalian, "yyyy-MM-dd"));
                    panel.add(spinnerTanggalPengembalian, gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    panel.add(new JLabel("Kondisi Buku Saat Dikembalikan:"), gbc);
                    gbc.gridx = 1;
                    String[] kondisiOptions = {"Baik", "Robek", "Kotor", "Hilang Halaman"};
                    JComboBox<String> cbKondisiBuku = new JComboBox<>(kondisiOptions);
                    panel.add(cbKondisiBuku, gbc);

                    int inputOption = JOptionPane.showConfirmDialog(TransaksiView.this, panel, "Proses Pengembalian", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                    if (inputOption != JOptionPane.OK_OPTION) {
                        return; // batal proses
                    }

                    // Ambil input user
                    java.util.Date tanggalPengembalianUtil = (java.util.Date) spinnerTanggalPengembalian.getValue();
                    Date tanggalPengembalian = new Date(tanggalPengembalianUtil.getTime());
                    String kondisiBuku = (String) cbKondisiBuku.getSelectedItem();

                    // Hitung keterlambatan
                    long diffMillis = tanggalPengembalian.getTime() - tanggalKembali.getTime();
                    long keterlambatanHari = TimeUnit.DAYS.convert(diffMillis, TimeUnit.MILLISECONDS);
                    if (keterlambatanHari < 0) {
                        keterlambatanHari = 0;
                    }

                    // Hitung denda
                    int dendaPerHari = 2000;
                    int dendaKondisi = 0;
                    switch (kondisiBuku) {
                        case "Robek":
                            dendaKondisi = 10000;
                            break;
                        case "Kotor":
                            dendaKondisi = 5000;
                            break;
                        case "Hilang Halaman":
                            dendaKondisi = 20000;
                            break;
                        default:
                            dendaKondisi = 0;
                    }
                    int dendaKeterlambatan = (int) (keterlambatanHari * dendaPerHari);
                    int totalDenda = dendaKeterlambatan + dendaKondisi;

                    // Buat panel konfirmasi pembayaran
                    JPanel konfirmasiPanel = new JPanel(new GridBagLayout());
                    gbc = new GridBagConstraints();
                    gbc.insets = new Insets(5, 5, 5, 5);
                    gbc.anchor = GridBagConstraints.WEST;

                    gbc.gridx = 0;
                    gbc.gridy = 0;
                    konfirmasiPanel.add(new JLabel("Tanggal Jatuh Tempo:"), gbc);
                    gbc.gridx = 1;
                    konfirmasiPanel.add(new JLabel(tanggalKembali.toString()), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    konfirmasiPanel.add(new JLabel("Tanggal Pengembalian:"), gbc);
                    gbc.gridx = 1;
                    konfirmasiPanel.add(new JLabel(tanggalPengembalian.toString()), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    konfirmasiPanel.add(new JLabel("Keterlambatan:"), gbc);
                    gbc.gridx = 1;
                    konfirmasiPanel.add(new JLabel(keterlambatanHari + " hari"), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    konfirmasiPanel.add(new JLabel("Denda Keterlambatan:"), gbc);
                    gbc.gridx = 1;
                    konfirmasiPanel.add(new JLabel("Rp" + dendaKeterlambatan), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    konfirmasiPanel.add(new JLabel("Kondisi Buku:"), gbc);
                    gbc.gridx = 1;
                    konfirmasiPanel.add(new JLabel(kondisiBuku), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    konfirmasiPanel.add(new JLabel("Denda Kerusakan:"), gbc);
                    gbc.gridx = 1;
                    konfirmasiPanel.add(new JLabel("Rp" + dendaKondisi), gbc);

                    gbc.gridx = 0;
                    gbc.gridy++;
                    konfirmasiPanel.add(new JLabel("Total Denda:"), gbc);
                    gbc.gridx = 1;
                    konfirmasiPanel.add(new JLabel("Rp" + totalDenda), gbc);

                    // Tombol Bayar dan Kembali
                    Object[] options = {"Bayar", "Kembali"};
                    int konfirmasiOption = JOptionPane.showOptionDialog(
                            TransaksiView.this,
                            konfirmasiPanel,
                            "Konfirmasi Pembayaran Denda",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.PLAIN_MESSAGE,
                            null,
                            options,
                            options[0]
                    );

                    if (konfirmasiOption == JOptionPane.YES_OPTION) {
                        // Proses simpan data, update DB, dll
                        boolean berhasil = new PeminjamanController().selesaikanPeminjaman(idPinjam, tanggalPengembalian, kondisiBuku, totalDenda);
                        if (berhasil) {
                            JOptionPane.showMessageDialog(TransaksiView.this, "Transaksi pengembalian selesai.\nTerima kasih.");
                            tampilkanPeminjaman();
                            break; // keluar loop
                        } else {
                            JOptionPane.showMessageDialog(TransaksiView.this, "Gagal menyelesaikan transaksi pengembalian.", "Error", JOptionPane.ERROR_MESSAGE);
                            // Tetap di loop untuk koreksi input
                        }
                    } else {
                        // Kembali ke dialog input untuk edit ulang, ulangi loop
                        // jadi tidak break
                    }

                }
            }
        });

    }

    private void tampilkanPeminjaman() {
        model.setColumnIdentifiers(new Object[]{
            "ID Peminjaman", "Kode Anggota", "Nama Anggota", "Kode Buku", "NIP Pegawai", "Tanggal Pinjam", "Tanggal Kembali", "Jumlah Pinjam"
        });
        model.setRowCount(0);
        ArrayList<Peminjaman> list = new PeminjamanController().getAll();
        for (Peminjaman p : list) {
            model.addRow(new Object[]{
                p.getIdPeminjaman(),
                p.getKodeAnggota(),
                p.getNamaAnggota(),
                p.getKodeBuku(),
                p.getNip(),
                p.getTanggalPinjam(),
                p.getTanggalKembali(),
                p.getTotalPinjam()
            });
        }
    }

    private void tampilkanArsip() {
        model.setColumnIdentifiers(new Object[]{
            "ID Arsip", "Kode Anggota", "Kode Buku", "NIP Pegawai", "Tanggal Pinjam",
            "Tanggal Kembali", "Tanggal Pengembalian", "Total Pinjam", "Kondisi Buku", "Total Denda"
        });

        ArrayList<ArsipPeminjaman> listArsip = new ArsipPeminjamanController().getAllArsip();
        model.setRowCount(0);

        for (ArsipPeminjaman arsip : listArsip) {
            model.addRow(new Object[]{
                arsip.getIdArsip(),
                arsip.getKodeAnggota(),
                arsip.getKodeBuku(),
                arsip.getNipPegawai(),
                arsip.getTanggalPinjam(),
                arsip.getTanggalKembali(),
                arsip.getTanggalPengembalian(),
                arsip.getTotalPinjam(),
                arsip.getKondisiBuku(),
                arsip.getTotalDenda()
            });
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TransaksiView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TransaksiView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TransaksiView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TransaksiView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

    
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
